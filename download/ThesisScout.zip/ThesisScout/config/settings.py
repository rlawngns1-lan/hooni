"""Thesis Scout 전역 설정. 경로·API 키는 이 파일 한 곳에서만 관리한다."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

# 프로젝트 최상위 폴더
BASE_DIR: Path = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

# --- 경로 ---
DATA_DIR: Path = BASE_DIR / "data"
PAPERS_DIR: Path = DATA_DIR / "papers"
DB_PATH: Path = DATA_DIR / "thesis_scout.db"
CORE_JOURNALS_PATH: Path = BASE_DIR / "config" / "core_journals.yaml"

# --- 외부 호출 공통 정책 ---
HTTP_TIMEOUT_SEC: float = 10.0
HTTP_MAX_RETRIES: int = 3
SEARCH_CACHE_HOURS: int = 24


def env(name: str) -> str | None:
    """환경 변수를 읽는다. 비어 있으면 None 을 돌려준다."""
    value = os.getenv(name, "").strip()
    return value or None


S2_API_KEY = env("S2_API_KEY")
OPENALEX_API_KEY = env("OPENALEX_API_KEY")
UNPAYWALL_EMAIL = env("UNPAYWALL_EMAIL")
CROSSREF_MAILTO = env("CROSSREF_MAILTO")
CORE_API_KEY = env("CORE_API_KEY")
KCI_API_KEY = env("KCI_API_KEY")
RISS_API_KEY = env("RISS_API_KEY")
LIBRARY_PROXY_PREFIX = env("LIBRARY_PROXY_PREFIX")

# --- 공개(인터넷) 모드 — 내 컴퓨터에서는 비워 둔다 ---
# Streamlit Community Cloud 의 Secrets 에 최상위로 적은 값은 환경 변수로도 읽힌다.
PUBLIC_MODE: bool = (env("THESIS_SCOUT_PUBLIC") or "").lower() in ("1", "true", "yes")
DATABASE_URL = env("DATABASE_URL")  # 예: Neon 무료 PostgreSQL 주소 (공개 모드에서 회원별 서재 저장)
