"""DB 연결과 테이블 생성.

- 내 컴퓨터 모드: data/thesis_scout.db (SQLite)
- 공개 모드: 설정의 DATABASE_URL (예: Neon 무료 PostgreSQL — postgresql://...?sslmode=require)
"""

from __future__ import annotations

import logging
from functools import lru_cache

from sqlalchemy import inspect, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.engine import Engine
from sqlmodel import Session, SQLModel, create_engine

from app import models  # noqa: F401  (테이블 등록용)
from config import settings


def default_db_url() -> str:
    """기본 DB 주소: DATABASE_URL 이 있으면 그것, 없으면 내 컴퓨터의 SQLite 파일."""
    if settings.DATABASE_URL:
        url = settings.DATABASE_URL
        # 일부 서비스는 'postgres://' 로 주는데 SQLAlchemy 는 'postgresql://' 만 안다
        return "postgresql://" + url[len("postgres://"):] if url.startswith("postgres://") else url
    settings.DATA_DIR.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{settings.DB_PATH.as_posix()}"


@lru_cache(maxsize=4)
def get_engine(db_url: str | None = None) -> Engine:
    """DB 엔진을 만들고, 없는 테이블을 생성한다."""
    db_url = db_url or default_db_url()
    if db_url.startswith("sqlite"):
        engine = create_engine(db_url, connect_args={"check_same_thread": False})
    else:
        # 무료 서버 DB 는 쉬다가 깨어나므로, 쓰기 전에 연결이 살아 있는지 확인한다
        engine = create_engine(db_url, pool_pre_ping=True, pool_recycle=300)
    try:
        SQLModel.metadata.create_all(engine)
        _add_missing_columns(engine)
    except SQLAlchemyError as e:
        # 오류 화면에 DB 주소(비밀번호 포함)가 드러나지 않도록 자세한 내용은 숨긴다
        logging.getLogger(__name__).error("DB 연결 실패: %s", type(e).__name__)
        raise RuntimeError("데이터베이스에 연결하지 못했습니다 — 잠시 후 다시 시도하거나 관리자에게 알려 주세요.") from None
    return engine


def _sql_default(col) -> str:
    """새 열을 추가할 때 기존 행에 넣을 기본값 (SQL 문법)."""
    arg = getattr(col.default, "arg", None)
    if isinstance(arg, bool):
        return " DEFAULT FALSE" if not arg else " DEFAULT TRUE"
    if isinstance(arg, (int, float)):
        return f" DEFAULT {arg}"
    if isinstance(arg, str):
        return " DEFAULT '" + arg.replace("'", "''") + "'"
    return ""


def _add_missing_columns(engine: Engine) -> None:
    """예전 버전으로 만든 DB 에 새로 생긴 열을 추가한다 (기존 데이터는 그대로 두고 기본값을 채운다).

    예: 서재에 owner 열이 새로 생기면 기존 항목은 모두 'local'(내 컴퓨터 사용자) 것이 된다.
    """
    insp = inspect(engine)
    with engine.begin() as conn:
        for table in SQLModel.metadata.sorted_tables:
            if not insp.has_table(table.name):
                continue
            existing = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in existing:
                    continue
                col_type = col.type.compile(dialect=engine.dialect)
                conn.execute(text(f'ALTER TABLE "{table.name}" ADD COLUMN "{col.name}" {col_type}{_sql_default(col)}'))


def get_session(db_url: str | None = None) -> Session:
    """DB 세션을 연다. `with get_session() as s:` 로 사용."""
    return Session(get_engine(db_url), expire_on_commit=False)
