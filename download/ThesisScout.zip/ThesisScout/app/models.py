"""데이터 모델. 검색 결과용 Paper 와 SQLite 테이블들을 정의한다."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import UniqueConstraint
from sqlmodel import Field, SQLModel

from app.context import LOCAL_OWNER

# 문헌 유형 값 (필터·표시에 사용)
DOC_TYPE_LABELS: dict[str, str] = {
    "journal": "저널 논문",
    "thesis": "학위논문",
    "report": "보고서",
    "other": "기타",
}


def utcnow() -> datetime:
    """현재 UTC 시각을 돌려준다."""
    return datetime.now(timezone.utc)


class Paper(SQLModel):
    """검색 결과 한 건 (여러 소스의 결과를 병합한 형태)."""

    doi: str | None = None
    title: str  # 한글 제목이 있으면 한글 제목
    title_alt: str | None = None  # 다른 언어 제목 (예: 국내 학술지의 영문 제목)
    authors: list[str] = Field(default_factory=list)
    year: int | None = None
    venue: str | None = None
    volume: str | None = None  # 권
    issue: str | None = None  # 호
    pages: str | None = None  # 쪽 (예: "121-145" 또는 논문번호)
    publisher: str | None = None
    abstract: str | None = None
    tldr: str | None = None
    language: str | None = None  # "ko" / "en" / None
    citation_count: int | None = None
    oa_pdf_url: str | None = None
    landing_url: str | None = None
    doc_type: str = "other"  # DOC_TYPE_LABELS 의 키
    sources: list[str] = Field(default_factory=list)  # 이 논문을 찾은 소스 이름들
    is_core_journal: bool = False
    relevance: float = 0.0  # 소스별 순위를 합친 관련도 점수
    is_influential: bool = False  # 인용 네트워크: Semantic Scholar 가 '영향력 있는 인용'으로 표시

    @property
    def is_oa(self) -> bool:
        """합법적으로 공개된 PDF 링크가 있는지."""
        return bool(self.oa_pdf_url)


READ_STATUS_LABELS: dict[str, str] = {
    "unread": "안 읽음",
    "reading": "읽는 중",
    "done": "완료",
}


class PaperRecord(SQLModel, table=True):
    """DB 에 저장된 논문 (서재·요약·다운로드가 참조)."""

    __table_args__ = {"extend_existing": True}  # Streamlit 이 파일 변경 후 다시 불러올 때 오류 방지

    id: int | None = Field(default=None, primary_key=True)
    key: str = Field(index=True, unique=True)  # DOI, 없으면 정규화 제목|연도
    doi: str | None = None
    title: str
    title_alt: str | None = None
    authors_json: str = "[]"
    year: int | None = None
    venue: str | None = None
    volume: str | None = None
    issue: str | None = None
    pages: str | None = None
    publisher: str | None = None
    abstract: str | None = None
    tldr: str | None = None
    language: str | None = None
    citation_count: int | None = None
    oa_pdf_url: str | None = None
    landing_url: str | None = None
    doc_type: str = "other"
    sources_json: str = "[]"
    is_core_journal: bool = False
    local_pdf_path: str | None = None
    crossref_checked: bool = False  # Crossref 로 서지정보(권·호·쪽)를 보완해 봤는지
    created_at: datetime = Field(default_factory=utcnow)


class Project(SQLModel, table=True):
    """논문 묶음 (예: '1장 이론적 배경'). 이름은 사용자마다 따로 겹치지 않으면 된다."""

    __table_args__ = (
        UniqueConstraint("owner", "name", name="uq_project_owner_name"),
        {"extend_existing": True},  # Streamlit 이 파일 변경 후 다시 불러올 때 오류 방지
    )

    id: int | None = Field(default=None, primary_key=True)
    owner: str = Field(default=LOCAL_OWNER, index=True)  # 내 컴퓨터 모드는 'local', 공개 모드는 로그인 사용자
    name: str
    description: str = ""
    created_at: datetime = Field(default_factory=utcnow)


class LibraryItem(SQLModel, table=True):
    """내 서재에 담긴 논문 한 건 (사용자마다 같은 논문은 한 번만)."""

    __table_args__ = (
        UniqueConstraint("owner", "paper_id", name="uq_libraryitem_owner_paper"),
        {"extend_existing": True},
    )

    id: int | None = Field(default=None, primary_key=True)
    owner: str = Field(default=LOCAL_OWNER, index=True)
    paper_id: int = Field(foreign_key="paperrecord.id")
    project_id: int | None = Field(default=None, foreign_key="project.id")
    tags_json: str = "[]"
    note: str = ""
    read_status: str = "unread"  # READ_STATUS_LABELS 의 키
    added_at: datetime = Field(default_factory=utcnow)


class SearchCache(SQLModel, table=True):
    """소스별 검색 결과 캐시 (24시간 유효). 공개 자료라 모든 사용자가 함께 쓴다."""

    __table_args__ = {"extend_existing": True}  # Streamlit 이 파일 변경 후 다시 불러올 때 오류 방지

    key: str = Field(primary_key=True)
    source: str
    payload: str  # Paper 목록 JSON
    created_at: datetime = Field(default_factory=utcnow)


class SavedSearch(SQLModel, table=True):
    """저장된 검색 — '새 논문 확인'으로 이후에 새로 나온 논문만 골라 보여준다."""

    __table_args__ = {"extend_existing": True}  # Streamlit 이 파일 변경 후 다시 불러올 때 오류 방지

    id: int | None = Field(default=None, primary_key=True)
    owner: str = Field(default=LOCAL_OWNER, index=True)
    query: str
    english_query: str | None = None
    filters_json: str = "{}"
    seen_keys_json: str = "[]"  # 지금까지 본 논문 키
    last_checked_at: datetime = Field(default_factory=utcnow)
    created_at: datetime = Field(default_factory=utcnow)


class SearchHistory(SQLModel, table=True):
    """검색 기록."""

    __table_args__ = {"extend_existing": True}  # Streamlit 이 파일 변경 후 다시 불러올 때 오류 방지

    id: int | None = Field(default=None, primary_key=True)
    owner: str = Field(default=LOCAL_OWNER, index=True)
    query: str
    expanded_keywords: str | None = None  # JSON 목록
    filters: str | None = None  # JSON
    created_at: datetime = Field(default_factory=utcnow)
