"""RISS OpenAPI 학위논문·국내학술논문 검색 — RISS_API_KEY 가 있을 때만 활성화.

확인한 공식 문서 (2026-11-26):
- 소개·신청 자격: https://www.riss.kr/apicenter/apiSearchIntro.do (비영리 기관(대학) 대상, 심사 후 승인)
- 학위논문(type=T): https://www.riss.kr/apicenter/apiSearchThesis.do
- 국내학술논문(type=A): https://www.riss.kr/apicenter/apiSearchDissKor.do
요점: GET http://www.riss.kr/openApi?key=..&version=1.0&type=T|A&keyword=..,
spubdate/epubdate=YYYY, rowcount(최대 100), XML 응답(오류는 <Error>/<ErrorMessage>).
초록 본문·DOI·피인용 수는 제공하지 않는다 (메타데이터만).
※ 개인에게는 키가 발급되지 않을 수 있음 → 키가 없으면 RISS 웹 검색 링크로 대신 안내한다.
※ 레코드 태그 구조는 실제 키로 받은 응답으로 아직 확인하지 못해, riss.title 자식을 가진 요소를 레코드로 본다.
"""

from __future__ import annotations

import asyncio
import re
import xml.etree.ElementTree as ET

import httpx

from app.models import Paper
from app.sources.base import BaseSource, SearchFilters, SourceError, detect_language

SEARCH_URL = "https://www.riss.kr/openApi"  # 문서엔 http 로 나오지만 https 도 응답함(2026-11-26 확인) → 키 보호를 위해 https
TYPES = {"T": "thesis", "A": "journal"}  # 학위논문, 국내학술논문


def _child(el: ET.Element, tag: str) -> str | None:
    found = el.find(tag)
    if found is None or found.text is None:
        return None
    return " ".join(found.text.split()) or None


def parse_response(xml_text: str, doc_type: str) -> list[Paper]:
    """RISS XML 응답을 파싱한다. 오류 코드가 있으면 SourceError."""
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        raise SourceError("RISS 응답을 읽을 수 없습니다 — 잠시 후 다시 시도하세요.") from e
    err_msg = _child(root, ".//ErrorMessage")
    err_code = _child(root, ".//Error")
    if err_msg or (err_code and err_code not in ("0", "000")):
        if err_code == "004" or (err_msg and "인증" in err_msg):
            raise SourceError("RISS 인증 실패 — `.env` 의 RISS_API_KEY 가 맞는지 확인하세요.")
        raise SourceError(f"RISS 오류: {err_msg or err_code}")
    papers: list[Paper] = []
    for rec in root.iter():
        title = _child(rec, "riss.title")
        if not title:
            continue
        year_match = re.search(r"\d{4}", _child(rec, "riss.pubdate") or "")
        authors = _child(rec, "riss.author") or ""
        papers.append(
            Paper(
                title=title,
                authors=[a.strip() for a in re.split(r"[;,]", authors) if a.strip()],
                year=int(year_match.group()) if year_match else None,
                venue=_child(rec, "riss.stype") or _child(rec, "riss.publisher"),
                language=detect_language(title),
                landing_url=_child(rec, "url"),
                doc_type=doc_type,
            )
        )
    return papers


class RISSSource(BaseSource):
    """RISS — 국내 학위논문·학술논문 (키 필수)."""

    name = "riss"
    label = "RISS"
    key_env = "RISS_API_KEY"
    key_required = True
    korean = True
    min_interval_sec = 0.5

    async def search(
        self, client: httpx.AsyncClient, query: str, filters: SearchFilters, limit: int = 25
    ) -> list[Paper]:
        """학위논문과 국내학술논문을 각각 검색해 번갈아 합친다."""

        async def one(rtype: str) -> list[Paper]:
            params: dict[str, str | int] = {
                "key": self.api_key or "",
                "version": "1.0",
                "type": rtype,
                "keyword": query,
                "rowcount": min(limit, 100),
            }
            if filters.year_from:
                params["spubdate"] = filters.year_from
            if filters.year_to:
                params["epubdate"] = filters.year_to
            resp = await self._get(client, SEARCH_URL, params=params)
            return parse_response(resp.text, TYPES[rtype])

        theses, articles = await asyncio.gather(one("T"), one("A"))
        merged: list[Paper] = []
        for i in range(max(len(theses), len(articles))):
            merged.extend(lst[i] for lst in (articles, theses) if i < len(lst))
        return merged
