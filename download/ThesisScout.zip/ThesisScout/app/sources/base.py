"""검색 소스 공통 인터페이스와 HTTP 호출 규칙(타임아웃·재시도·속도 제한)."""

from __future__ import annotations

import asyncio
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import httpx

from app.models import Paper
from config import settings

USER_AGENT = "ThesisScout/0.1 (personal research tool)"
HANGUL_RE = re.compile(r"[가-힣]")


class SourceError(Exception):
    """사용자에게 그대로 보여줄 한국어 오류 메시지를 담는 예외."""


@dataclass
class SearchFilters:
    """검색 필터."""

    year_from: int | None = None
    year_to: int | None = None
    oa_only: bool = False
    min_citations: int = 0
    languages: list[str] = field(default_factory=list)  # 비어 있으면 전체. "ko"/"en"
    doc_types: list[str] = field(default_factory=list)  # 비어 있으면 전체

    def cache_key(self) -> str:
        """캐시 키에 쓰일 문자열 (API 쪽에 실제로 전달되는 조건만)."""
        return f"{self.year_from}-{self.year_to}-{self.oa_only}-{self.min_citations}"


def detect_language(text: str | None) -> str | None:
    """한글이 들어 있으면 'ko', 아니면 'en' (텍스트가 없으면 None)."""
    if not text:
        return None
    return "ko" if HANGUL_RE.search(text) else "en"


def clean_doi(doi: str | None) -> str | None:
    """DOI 를 '10.xxxx/...' 소문자 형태로 정리한다."""
    if not doi:
        return None
    doi = doi.strip().lower()
    doi = re.sub(r"^(https?://(dx\.)?doi\.org/|doi:)", "", doi)
    return doi if doi.startswith("10.") else None


def clean_biblio(value: object) -> str | None:
    """권·호·쪽 값을 정리한다: 공백 정리, 긴 대시(–, —)는 '-' 로. 빈 값은 None."""
    if value is None:
        return None
    s = re.sub(r"\s+", " ", str(value)).strip()
    s = re.sub(r"\s*[–—‐-]\s*", "-", s)
    return s or None


def page_range(first: object, last: object) -> str | None:
    """시작쪽·끝쪽을 '121-145' 로 합친다."""
    a, b = clean_biblio(first), clean_biblio(last)
    if a and b and a != b:
        return f"{a}-{b}"
    return a or b


class RateLimiter:
    """요청 사이 최소 간격을 지키게 하는 간단한 속도 제한기."""

    def __init__(self, min_interval_sec: float) -> None:
        self.min_interval = min_interval_sec
        self._last = 0.0
        self._lock: asyncio.Lock | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

    async def wait(self) -> None:
        """직전 요청 후 min_interval 이 지날 때까지 기다린다 (검색마다 이벤트 루프가 바뀌어도 동작)."""
        loop = asyncio.get_running_loop()
        if self._lock is None or self._loop is not loop:
            self._lock, self._loop = asyncio.Lock(), loop
        async with self._lock:
            gap = time.monotonic() - self._last
            if gap < self.min_interval:
                await asyncio.sleep(self.min_interval - gap)
            self._last = time.monotonic()


class ApiClient:
    """외부 API 호출 공통 기능: 키 확인, 타임아웃·재시도·속도 제한, 한국어 오류."""

    name: str = "base"  # 내부 이름 (캐시 키 등)
    label: str = "Base"  # 화면 표시 이름
    key_env: str | None = None  # 필요한 환경 변수 이름 (없으면 None)
    key_required: bool = False  # True 면 키가 없을 때 비활성화
    korean: bool = False  # 한국 소스면 True (한국어 검색어를 그대로 보냄)
    min_interval_sec: float = 1.0  # 요청 간 최소 간격
    backoff_base_sec: float = 1.0  # 재시도 대기 기본값 (테스트에서 0 으로 바꿈)

    def __init__(self) -> None:
        self._limiter = RateLimiter(self.min_interval_sec)

    @property
    def api_key(self) -> str | None:
        """설정된 API 키 (없으면 None)."""
        return settings.env(self.key_env) if self.key_env else None

    def is_enabled(self) -> bool:
        """키가 필요한 소스는 키가 있어야 활성화된다."""
        return not self.key_required or bool(self.api_key)

    def disabled_reason(self) -> str:
        """비활성화된 이유 (한국어)."""
        return f"이 소스는 키가 없어 비활성화됨 — 설정의 `.env` 에 {self.key_env} 를 입력하세요."

    async def _get(
        self,
        client: httpx.AsyncClient,
        url: str,
        *,
        params: dict | None = None,
        headers: dict | None = None,
        allow_status: tuple[int, ...] = (),
    ) -> httpx.Response:
        """GET 요청. 타임아웃 10초, 429/5xx/네트워크 오류 시 지수 백오프로 최대 3회 재시도."""
        hdrs = {"User-Agent": USER_AGENT, **(headers or {})}
        last_status: int | None = None
        for attempt in range(settings.HTTP_MAX_RETRIES + 1):
            await self._limiter.wait()
            try:
                resp = await client.get(
                    url, params=params, headers=hdrs, timeout=settings.HTTP_TIMEOUT_SEC
                )
            except httpx.TimeoutException:
                last_status = None
                err = f"{self.label} 응답 시간이 초과됐습니다 — 잠시 후 다시 시도하세요."
            except httpx.HTTPError:
                last_status = None
                err = f"{self.label} 에 연결할 수 없습니다 — 인터넷 연결을 확인하세요."
            else:
                if resp.status_code < 400 or resp.status_code in allow_status:
                    return resp
                last_status = resp.status_code
                if resp.status_code not in (429, 500, 502, 503, 504):
                    raise SourceError(self._status_message(resp.status_code))
                err = self._status_message(resp.status_code)
            if attempt < settings.HTTP_MAX_RETRIES:
                await asyncio.sleep(self._retry_delay(attempt, resp if last_status else None))
        raise SourceError(err if last_status is None else self._status_message(last_status))

    def _retry_delay(self, attempt: int, resp: httpx.Response | None) -> float:
        """재시도 전 대기 시간: 서버가 Retry-After 를 주면 따르고(최대 10초), 아니면 지수 백오프."""
        delay = self.backoff_base_sec * (2**attempt)
        if resp is not None and self.backoff_base_sec > 0:
            try:
                delay = max(delay, min(float(resp.headers.get("Retry-After", 0)), 10.0))
            except ValueError:
                pass
        return delay

    def _status_message(self, status: int) -> str:
        """HTTP 상태 코드를 한국어 안내로 바꾼다."""
        if status == 429:
            hint = (
                f"설정에서 {self.key_env} 를 등록하면 한도가 늘어납니다."
                if self.key_env and not self.api_key
                else "잠시 후 다시 시도하세요."
            )
            return f"{self.label} 요청 한도 초과 — 1분 후 다시 시도하세요. {hint}"
        if status in (401, 403):
            return f"{self.label} 인증 실패 — `.env` 의 {self.key_env} 값이 맞는지 확인하세요."
        if status >= 500:
            return f"{self.label} 서버 오류({status}) — 잠시 후 다시 시도하세요."
        return f"{self.label} 요청 오류({status}) — 검색어를 바꿔 다시 시도하세요."


class BaseSource(ApiClient, ABC):
    """모든 검색 소스가 따르는 공통 인터페이스: search(query, filters) -> list[Paper]."""

    @abstractmethod
    async def search(
        self, client: httpx.AsyncClient, query: str, filters: SearchFilters, limit: int = 25
    ) -> list[Paper]:
        """주제로 논문을 검색해 관련도 순 Paper 목록을 돌려준다."""
