"""Semantic Scholar Academic Graph API 검색.

확인한 공식 문서 (2026-11-26):
- OpenAPI 명세: https://api.semanticscholar.org/graph/v1/swagger.json
- 키·요청 한도: https://www.semanticscholar.org/product/api , https://www.semanticscholar.org/product/api/tutorial
요점: GET /graph/v1/paper/search, limit 최대 100, year="2010-2020", openAccessPdf(값 없는 플래그),
minCitationCount, 키는 `x-api-key` 헤더, 한도 초과 시 HTTP 429. 검색어의 하이픈은 공백으로 바꿔야 한다.
"""

from __future__ import annotations

import httpx

from app.models import Paper
from app.sources.base import BaseSource, SearchFilters, SourceError, clean_biblio, clean_doi, detect_language

SEARCH_URL = "https://api.semanticscholar.org/graph/v1/paper/search"
FIELDS = (
    "title,authors,year,venue,journal,abstract,tldr,citationCount,"
    "externalIds,openAccessPdf,url,publicationTypes"
)
# 인용 네트워크: GET /paper/{paper_id}/citations | /references (paper_id 는 "DOI:10.xxx" 형식 가능)
# limit 최대 1000, offset·next 로 페이지. 응답 data[] 의 citingPaper / citedPaper 안에 논문 필드, isInfluential.
PAPER_URL = "https://api.semanticscholar.org/graph/v1/paper/{paper_id}/{direction}"
RELATED_FIELDS = (
    "title,authors,year,venue,journal,abstract,citationCount,"
    "externalIds,openAccessPdf,url,publicationTypes,isInfluential"
)


def _doc_type(types: list[str] | None) -> str:
    """Semantic Scholar 문헌 유형을 내부 유형으로 바꾼다."""
    types = types or []
    if "JournalArticle" in types or "Review" in types:
        return "journal"
    return "other"


def parse_item(item: dict) -> Paper | None:
    """API 응답의 논문 한 건을 Paper 로 바꾼다. 제목이 없으면 None."""
    title = (item.get("title") or "").strip()
    if not title:
        return None
    journal = item.get("journal") or {}
    oa = item.get("openAccessPdf") or {}
    tldr = item.get("tldr") or {}
    abstract = item.get("abstract")
    return Paper(
        doi=clean_doi((item.get("externalIds") or {}).get("DOI")),
        title=title,
        authors=[a.get("name", "") for a in item.get("authors") or [] if a.get("name")],
        year=item.get("year"),
        venue=journal.get("name") or item.get("venue") or None,
        volume=clean_biblio(journal.get("volume")),
        pages=clean_biblio(journal.get("pages")),
        abstract=abstract,
        tldr=tldr.get("text"),
        language=detect_language(f"{title} {abstract or ''}"),
        citation_count=item.get("citationCount"),
        oa_pdf_url=oa.get("url") or None,
        landing_url=item.get("url"),
        doc_type=_doc_type(item.get("publicationTypes")),
    )


class SemanticScholarSource(BaseSource):
    """Semantic Scholar — 메인 검색 소스 (키 선택)."""

    name = "semantic_scholar"
    label = "Semantic Scholar"
    key_env = "S2_API_KEY"
    key_required = False
    min_interval_sec = 1.1  # 키 사용 시 초당 1회 제한
    backoff_base_sec = 2.0  # 키 없는 공용 한도는 자주 붐벼서 2·4·8초 간격으로 재시도

    async def search(
        self, client: httpx.AsyncClient, query: str, filters: SearchFilters, limit: int = 25
    ) -> list[Paper]:
        """주제로 논문을 검색한다."""
        params: dict[str, str | int] = {
            "query": query.replace("-", " "),
            "fields": FIELDS,
            "limit": min(limit, 100),
        }
        if filters.year_from or filters.year_to:
            params["year"] = f"{filters.year_from or ''}-{filters.year_to or ''}"
        if filters.oa_only:
            params["openAccessPdf"] = ""
        if filters.min_citations:
            params["minCitationCount"] = filters.min_citations
        headers = {"x-api-key": self.api_key} if self.api_key else {}
        resp = await self._get(client, SEARCH_URL, params=params, headers=headers)
        data = resp.json().get("data") or []
        return [p for p in (parse_item(i) for i in data) if p]

    async def related(
        self, client: httpx.AsyncClient, doi: str, direction: str, *, limit: int = 100, offset: int = 0
    ) -> tuple[list[Paper], int | None]:
        """인용 네트워크 한 쪽을 가져온다.

        direction="citations": 이 논문을 인용한 논문(후속 연구),
        direction="references": 이 논문이 인용한 논문(선행 연구).
        돌려주는 값: (논문 목록, 다음 페이지 시작 위치 — 없으면 None).
        """
        if direction not in ("citations", "references"):
            raise ValueError(direction)
        url = PAPER_URL.format(paper_id=f"DOI:{doi}", direction=direction)
        params = {"fields": RELATED_FIELDS, "limit": min(limit, 1000), "offset": offset}
        headers = {"x-api-key": self.api_key} if self.api_key else {}
        resp = await self._get(client, url, params=params, headers=headers, allow_status=(404,))
        if resp.status_code == 404:
            raise SourceError(
                "Semantic Scholar 에서 이 논문(DOI)을 찾지 못했습니다 — 인용 네트워크를 볼 수 없습니다. "
                "Google Scholar 의 '인용' 링크를 이용해 보세요."
            )
        body = resp.json()
        inner = "citingPaper" if direction == "citations" else "citedPaper"
        papers = []
        for row in body.get("data") or []:
            p = parse_item(row.get(inner) or {})
            if p:
                p.is_influential = bool(row.get("isInfluential"))
                p.sources = [self.name]
                papers.append(p)
        return papers, body.get("next")
