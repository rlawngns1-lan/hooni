"""Crossref — DOI 로 서지정보(권·호·쪽·출판사·저자 이름) 보완. 키 없이 사용 가능.

확인한 공식 문서 (2026-11-26):
- REST API 개요: https://www.crossref.org/documentation/retrieve-metadata/rest-api/
- 사용 팁: https://www.crossref.org/documentation/retrieve-metadata/rest-api/tips-for-using-the-crossref-rest-api/
- 접근·요청 한도: https://www.crossref.org/documentation/retrieve-metadata/rest-api/access-and-authentication/
요점: GET https://api.crossref.org/works/{doi}. 응답은 {"status":"ok","message":{...}}.
message 안: title[], author[{given,family}|{name}], container-title[], volume, issue, page,
article-number, publisher, issued.date-parts, type. 공용(public) 풀은 DOI 조회 초당 5회·동시 1개,
mailto 파라미터를 붙이면 polite 풀(초당 10회). 한도 초과 시 429.
CROSSREF_MAILTO 가 비어 있어도 공용 풀로 동작한다 (이메일을 임의로 넣지 않는다).
검색(2026-11-26 실제 요청으로 확인): GET /works?query.bibliographic=...&rows=&filter=type:..,from-pub-date:YYYY,
until-pub-date:YYYY&select=... — 한국어 검색어로 국내 학술지(DOI 등록 KCI 등재지 등)도 찾힌다.
공용 풀 검색 한도는 초당 1회·동시 1개. 같은 filter 이름을 여러 번 쓰면 OR 로 묶인다.
"""

from __future__ import annotations

import re
from urllib.parse import quote

import httpx

from app.models import Paper
from app.sources.base import (
    HANGUL_RE,
    ApiClient,
    BaseSource,
    SearchFilters,
    clean_biblio,
    clean_doi,
    detect_language,
)

WORKS_URL = "https://api.crossref.org/works/"
WORKS_SEARCH_URL = "https://api.crossref.org/works"
SEARCH_TYPES = ("journal-article", "dissertation", "report")
SEARCH_SELECT = (
    "DOI,title,original-title,author,container-title,volume,issue,page,article-number,publisher,"
    "issued,type,is-referenced-by-count,URL,abstract"
)  # 'language' 는 검색에서 select 할 수 없음 (400 select-not-available — 2026-11-26 확인)
TYPE_MAP = {
    "journal-article": "journal",
    "dissertation": "thesis",
    "report": "report",
    "report-component": "report",
}


def _first(v: object) -> str | None:
    """Crossref 의 배열 필드에서 첫 값을 꺼낸다."""
    if isinstance(v, list):
        return str(v[0]).strip() if v else None
    return str(v).strip() if v else None


def author_name(a: dict) -> str | None:
    """Crossref 저자 → 'Family, Given' (단체 저자는 name 그대로)."""
    family, given = (a.get("family") or "").strip(), (a.get("given") or "").strip()
    if family and given:
        return f"{family}, {given}"
    return family or (a.get("name") or "").strip() or None


def pick_titles(msg: dict) -> tuple[str | None, str | None]:
    """(대표 제목, 다른 언어 제목). 한글 제목이 있으면 한글을 대표로 한다.

    국내 학술지는 title 에 영문 제목, original-title 에 한글 제목을 넣는 경우가 많다
    (2026-11-26 실제 기록으로 확인, 예: 10.33528/kjma.2023.13.6.1).
    """
    candidates = [t.strip() for key in ("title", "original-title")
                  for t in (msg.get(key) or []) if isinstance(t, str) and t.strip()]
    if not candidates:
        return None, None
    korean = next((t for t in candidates if HANGUL_RE.search(t)), None)
    main = korean or candidates[0]
    other = next((t for t in candidates if t != main and not (korean and HANGUL_RE.search(t))), None)
    return main, other


def parse_work(msg: dict) -> Paper | None:
    """works/{doi} 응답의 message 를 Paper 로 바꾼다."""
    title, title_alt = pick_titles(msg)
    if not title:
        return None
    issued = ((msg.get("issued") or {}).get("date-parts") or [[None]])[0]
    authors = [n for n in (author_name(a) for a in msg.get("author") or []) if n]
    return Paper(
        doi=clean_doi(msg.get("DOI")),
        title=title,
        title_alt=title_alt,
        authors=authors,
        year=issued[0] if issued and isinstance(issued[0], int) else None,
        venue=_first(msg.get("container-title")),
        volume=clean_biblio(msg.get("volume")),
        issue=clean_biblio(msg.get("issue")),
        pages=clean_biblio(msg.get("page")) or clean_biblio(msg.get("article-number")),
        publisher=(msg.get("publisher") or "").strip() or None,
        doc_type=TYPE_MAP.get(msg.get("type") or "", "other"),
    )


def _strip_jats(text: str | None) -> str | None:
    """Crossref 초록의 JATS 태그(<jats:p> 등)를 지운다."""
    if not text:
        return None
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip() or None


def parse_search_item(item: dict) -> Paper | None:
    """works 검색 결과 한 건을 Paper 로 바꾼다 (피인용·링크·초록 포함)."""
    p = parse_work(item)
    if p is None:
        return None
    # Crossref 피인용 수(is-referenced-by-count)는 참고문헌을 Crossref 에 등록한 학술지끼리만 세므로
    # 국내 학술지는 거의 0 으로 나온다 → '모름(None)'으로 두어 피인용 필터에 잘못 걸리지 않게 한다.
    # (같은 논문이 Semantic Scholar·OpenAlex 에도 있으면 병합할 때 그쪽 피인용 수가 쓰인다.)
    p.citation_count = None
    p.landing_url = item.get("URL") or (f"https://doi.org/{p.doi}" if p.doi else None)
    p.abstract = _strip_jats(item.get("abstract"))
    # 제목·학술지명·저자 이름 중 한글이 있으면 한국어 문헌으로 본다
    p.language = detect_language(f"{p.title} {_first(item.get('container-title')) or ''} {' '.join(p.authors)}")
    return p


class CrossrefClient(ApiClient):
    """Crossref DOI 조회 (키 불필요, CROSSREF_MAILTO 가 있으면 polite 풀)."""

    name = "crossref"
    label = "Crossref"
    key_env = "CROSSREF_MAILTO"
    key_required = False
    min_interval_sec = 0.25  # 공용 풀 초당 5회 이하 (동시 1개 — 호출하는 쪽에서 순차 호출을 유지할 것)

    def _status_message(self, status: int) -> str:
        """Crossref 는 키가 없으므로 401/403 은 접근 차단으로 안내한다."""
        if status in (401, 403):
            return "Crossref 가 요청을 거절했습니다 — 잠시 후 다시 시도하세요. 계속되면 이 기능 없이 직접 권·호·쪽을 보충하세요."
        return super()._status_message(status)

    async def fetch(self, client: httpx.AsyncClient, doi: str) -> Paper | None:
        """DOI 의 서지정보를 돌려준다. Crossref 에 없는 DOI 면 None."""
        params = {"mailto": self.api_key} if self.api_key else None
        resp = await self._get(client, WORKS_URL + quote(doi, safe="/"), params=params, allow_status=(404,))
        if resp.status_code == 404:
            return None
        return parse_work(resp.json().get("message") or {})


class CrossrefSource(BaseSource):
    """Crossref 검색 — 키 없이 국내 학술지(DOI 를 등록한 KCI 등재지 다수 포함)까지 찾는 검색 소스.

    한국어 검색어를 그대로 보낸다(korean=True). 무료 공개 PDF 정보는 주지 않으므로
    'Open Access 만' 필터를 켜면 요청하지 않는다.
    """

    name = "crossref"
    label = "Crossref (국내 학술지 포함)"
    key_env = "CROSSREF_MAILTO"
    key_required = False
    korean = True
    min_interval_sec = 1.0  # 공용 풀 검색은 초당 1회·동시 1개

    async def search(
        self, client: httpx.AsyncClient, query: str, filters: SearchFilters, limit: int = 25
    ) -> list[Paper]:
        """제목·저자·학술지명(bibliographic)으로 논문을 검색한다."""
        if filters.oa_only:
            return []
        flt = [f"type:{t}" for t in SEARCH_TYPES]
        if filters.year_from:
            flt.append(f"from-pub-date:{filters.year_from}")
        if filters.year_to:
            flt.append(f"until-pub-date:{filters.year_to}")
        params: dict[str, str | int] = {
            "query.bibliographic": query,
            "rows": min(limit, 100),
            "filter": ",".join(flt),
            "select": SEARCH_SELECT,
        }
        if self.api_key:
            params["mailto"] = self.api_key
        resp = await self._get(client, WORKS_SEARCH_URL, params=params)
        items = (resp.json().get("message") or {}).get("items") or []
        return [p for p in (parse_search_item(i) for i in items) if p]
