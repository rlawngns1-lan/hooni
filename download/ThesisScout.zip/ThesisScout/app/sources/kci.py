"""KCI(한국학술지인용색인) OpenAPI 논문 검색 — KCI_API_KEY 가 있을 때만 활성화.

확인한 공식 문서 (2026-11-26):
- 명세: https://www.kci.go.kr/kciportal/po/openapi/openDataView.kci?datasetBean.dtstSeqNo=1
- 키 신청: https://www.kci.go.kr/kciportal/po/openapi/openApiKeyRequest.kci (로그인 필요, 관리자 승인 후 메일 발급)
요점: GET https://open.kci.go.kr/po/openapi/openApiSearch.kci?apiCode=articleSearch&key=..&title=..
dateFrom/dateTo=YYYYMM, page, displayCount(최대 100), XML 응답.
오류(예: 등록되지 않은 key)도 HTTP 200 + <resultMsg> 로 오므로 상태 코드가 아니라 내용으로 판단한다.
※ 응답 태그명은 명세 표 기준이며 실제 키로 받은 응답으로는 아직 확인하지 못함 — 키 발급 후 재확인할 것.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET

import httpx

from app.models import Paper
from app.sources.base import BaseSource, SearchFilters, SourceError, clean_doi, detect_language

SEARCH_URL = "https://open.kci.go.kr/po/openapi/openApiSearch.kci"


def _text(el: ET.Element | None) -> str | None:
    """요소의 텍스트를 공백 정리해 돌려준다."""
    if el is None or el.text is None:
        return None
    return " ".join(el.text.split()) or None


def _pick_lang(elements: list[ET.Element]) -> str | None:
    """lang 속성이 original 인 것을 우선, 없으면 첫 번째 값."""
    for el in elements:
        if el.get("lang") == "original" and _text(el):
            return _text(el)
    for el in elements:
        if _text(el):
            return _text(el)
    return None


def _to_int(value: str | None) -> int | None:
    try:
        return int(value) if value else None
    except ValueError:
        return None


def parse_record(rec: ET.Element) -> Paper | None:
    """<record> 한 건을 Paper 로 바꾼다."""
    art = rec.find("articleInfo")
    jour = rec.find("journalInfo")
    if art is None:
        return None
    title = _pick_lang(art.findall("title-group/article-title"))
    if not title:
        return None
    abstract = _pick_lang(art.findall("abstract-group/abstract"))
    cite = art.find("citation-count")
    return Paper(
        doi=clean_doi(_text(art.find("doi"))),
        title=title,
        authors=[t for t in (_text(a) for a in art.findall("author-group/author")) if t],
        year=_to_int(_text(jour.find("pub-year")) if jour is not None else None),
        venue=_text(jour.find("journal-name")) if jour is not None else None,
        abstract=abstract,
        language=detect_language(title),
        citation_count=_to_int(cite.get("kci")) if cite is not None else None,
        landing_url=_text(art.find("url")),
        doc_type="journal",
    )


def parse_response(xml_text: str) -> list[Paper]:
    """KCI XML 응답 전체를 파싱한다. 오류 메시지만 있으면 SourceError."""
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        raise SourceError("KCI 응답을 읽을 수 없습니다 — 잠시 후 다시 시도하세요.") from e
    records = root.findall(".//outputData/record")
    if not records:
        msg = _text(root.find(".//resultMsg"))
        if msg and ("key" in msg.lower() or "키" in msg):
            raise SourceError(f"KCI 인증 실패({msg}) — `.env` 의 KCI_API_KEY 가 맞는지, 사용 기간이 남았는지 확인하세요.")
        if msg and "없" not in msg:
            raise SourceError(f"KCI 오류: {msg}")
        return []
    return [p for p in (parse_record(r) for r in records) if p]


class KCISource(BaseSource):
    """KCI — 한국 학술지 논문 (키 필수)."""

    name = "kci"
    label = "KCI"
    key_env = "KCI_API_KEY"
    key_required = True
    korean = True
    min_interval_sec = 0.5

    async def search(
        self, client: httpx.AsyncClient, query: str, filters: SearchFilters, limit: int = 25
    ) -> list[Paper]:
        """제목에 검색어가 들어간 KCI 논문을 찾는다 (KCI API 는 제목 검색이 필수)."""
        params: dict[str, str | int] = {
            "apiCode": "articleSearch",
            "key": self.api_key or "",
            "title": query,
            "page": 1,
            "displayCount": min(limit, 100),
        }
        if filters.year_from:
            params["dateFrom"] = f"{filters.year_from}01"
        if filters.year_to:
            params["dateTo"] = f"{filters.year_to}12"
        resp = await self._get(client, SEARCH_URL, params=params)
        return parse_response(resp.text)
