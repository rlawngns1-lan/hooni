"""CORE API v3 — DOI 로 OA 본문 PDF 찾기. CORE_API_KEY 가 있을 때만 활성화.

확인한 공식 문서 (2026-11-26):
- API 문서: https://api.core.ac.uk/docs/v3
- OpenAPI 명세: https://api.core.ac.uk/swagger/v3.json
- 키 신청: https://core.ac.uk/services/api#form (무료)
요점: GET https://api.core.ac.uk/v3/search/works?q=doi:"{doi}"&limit=..,
인증은 `Authorization: Bearer KEY` 헤더. 개인 키 하루 1,000 토큰·분당 25회, 한도 초과 시 429.
work 의 downloadUrl 은 '원래 제공된 링크'라 PDF 가 아닐 수도 있음 → 다운로더가 %PDF 인지 검사한다.
문서 표는 camelCase(downloadUrl), 명세는 snake_case(download_url)로 달라 둘 다 읽는다.
※ fileserver 주소를 직접 만들어 대량 수집하는 것은 금지(키 정지) — API 가 준 주소만 쓴다.
"""

from __future__ import annotations

import httpx

from app.sources.base import ApiClient, clean_doi

SEARCH_URL = "https://api.core.ac.uk/v3/search/works"


def pick_pdf_url(results: list[dict], doi: str) -> str | None:
    """검색 결과 중 DOI 가 일치하는 work 의 다운로드 주소를 고른다."""
    for w in results:
        if clean_doi(w.get("doi")) != clean_doi(doi):
            continue
        url = w.get("downloadUrl") or w.get("download_url")
        if url:
            return url
        for link in w.get("links") or []:
            if link.get("type") == "download" and link.get("url"):
                return link["url"]
    return None


class CoreClient(ApiClient):
    """CORE DOI 조회 (키 필수)."""

    name = "core"
    label = "CORE"
    key_env = "CORE_API_KEY"
    key_required = True
    min_interval_sec = 2.5  # 분당 25회 이하

    async def find_pdf(self, client: httpx.AsyncClient, doi: str) -> str | None:
        """DOI 의 OA PDF 주소를 돌려준다. 없으면 None."""
        resp = await self._get(
            client,
            SEARCH_URL,
            params={"q": f'doi:"{doi}"', "limit": 5},
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        return pick_pdf_url(resp.json().get("results") or [], doi)
