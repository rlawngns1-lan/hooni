"""검색 소스 목록."""

from __future__ import annotations

from functools import lru_cache

from app.sources.base import BaseSource


@lru_cache(maxsize=1)
def get_sources() -> list[BaseSource]:
    """Phase 1 에서 사용하는 검색 소스 (화면 표시 순서).

    한 번만 만들어 재사용한다 — 검색을 연달아 해도 소스별 요청 간격(속도 제한)이 유지되도록.
    """
    from app.sources.crossref import CrossrefSource
    from app.sources.kci import KCISource
    from app.sources.openalex import OpenAlexSource
    from app.sources.riss import RISSSource
    from app.sources.semantic_scholar import SemanticScholarSource

    return [SemanticScholarSource(), OpenAlexSource(), CrossrefSource(), KCISource(), RISSSource()]
