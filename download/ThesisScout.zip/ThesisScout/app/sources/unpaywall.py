"""Unpaywall — DOI 로 합법적 OA PDF 위치 찾기. UNPAYWALL_EMAIL 이 있을 때만 활성화.

확인한 공식 문서 (2026-11-26):
- API: https://unpaywall.org/products/api
- 응답 형식: https://unpaywall.org/data-format
- OpenAlex 이관 안내: https://help.openalex.org/access/unpaywall.md
요점: GET https://api.unpaywall.org/v2/{doi}?email=..., 키 없음(이메일만), 하루 10만 건 이하.
이메일이 없거나 예시용 주소면 HTTP 422. 모르는 DOI 는 404. 제목 검색(/v2/search)은 2026-09-18 폐지됨.
best_oa_location.url_for_pdf 가 PDF 직링크(없으면 null), url_for_landing_page 는 웹페이지.
"""

from __future__ import annotations

from urllib.parse import quote

import httpx

from app.sources.base import ApiClient, SourceError

API_URL = "https://api.unpaywall.org/v2/"


def pick_pdf_url(data: dict) -> str | None:
    """응답에서 PDF 직링크를 고른다: best_oa_location 우선, 없으면 다른 OA 위치."""
    best = data.get("best_oa_location") or {}
    if best.get("url_for_pdf"):
        return best["url_for_pdf"]
    for loc in data.get("oa_locations") or []:
        if loc.get("url_for_pdf"):
            return loc["url_for_pdf"]
    return None


class UnpaywallClient(ApiClient):
    """Unpaywall DOI 조회 (이메일 필수)."""

    name = "unpaywall"
    label = "Unpaywall"
    key_env = "UNPAYWALL_EMAIL"
    key_required = True
    min_interval_sec = 0.2

    def disabled_reason(self) -> str:
        """비활성화 이유."""
        return "Unpaywall 은 이메일이 없어 비활성화됨 — `.env` 에 UNPAYWALL_EMAIL 을 입력하세요 (키 신청 불필요)."

    async def find_pdf(self, client: httpx.AsyncClient, doi: str) -> str | None:
        """DOI 의 합법적 OA PDF 주소를 돌려준다. 없으면 None."""
        resp = await self._get(
            client, API_URL + quote(doi, safe="/"), params={"email": self.api_key or ""}, allow_status=(404, 422)
        )
        if resp.status_code == 404:
            return None
        if resp.status_code == 422:
            raise SourceError(
                "Unpaywall 이 이메일을 받지 않았습니다 — `.env` 의 UNPAYWALL_EMAIL 에 본인이 실제로 쓰는 이메일을 넣으세요."
            )
        return pick_pdf_url(resp.json())
