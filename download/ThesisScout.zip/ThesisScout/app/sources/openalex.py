"""OpenAlex works 검색.

확인한 공식 문서 (2026-11-26, docs.openalex.org 는 help.openalex.org 로 이전됨):
- 인증: https://help.openalex.org/api-reference/authentication
- 검색: https://help.openalex.org/api-entities/works/search-works
- 필터: https://help.openalex.org/how-to-use-the-api/get-lists-of-entities/filter-entity-lists
- 페이지: https://help.openalex.org/how-to-use-the-api/get-lists-of-entities/paging
- select: https://help.openalex.org/how-to-use-the-api/get-lists-of-entities/select-fields
- Work 객체: https://help.openalex.org/api-entities/works/work-object
요점: 키 없이도 기본 검색 가능, 무료 키(`api_key` 파라미터)를 쓰면 일일 한도 10배.
mailto(polite pool)는 폐지됨. per_page 최대 100, select 는 최상위 필드만 가능.
초록은 abstract_inverted_index({단어: [위치]}) 로만 제공되므로 복원해야 한다.
인용 네트워크 (2026-11-26 실제 요청으로 확인): GET /works/doi:{doi} 로 W… ID 를 얻고,
filter=cites:W… (인용한 논문) / filter=cited_by:W… (참고문헌), sort=cited_by_count:desc, meta.count 가 전체 수.
"""

from __future__ import annotations

import httpx

from app.models import Paper
from app.sources.base import (
    BaseSource,
    SearchFilters,
    SourceError,
    clean_biblio,
    clean_doi,
    detect_language,
    page_range,
)

WORKS_URL = "https://api.openalex.org/works"
SELECT = (
    "id,doi,display_name,publication_year,authorships,primary_location,"
    "abstract_inverted_index,cited_by_count,open_access,best_oa_location,language,type,biblio"
)
TYPE_MAP = {"article": "journal", "review": "journal", "dissertation": "thesis", "report": "report"}


def restore_abstract(inverted: dict[str, list[int]] | None) -> str | None:
    """abstract_inverted_index 를 원래 문장 순서로 복원한다."""
    if not inverted:
        return None
    positions: list[tuple[int, str]] = [
        (pos, word) for word, idxs in inverted.items() for pos in idxs
    ]
    positions.sort()
    return " ".join(word for _, word in positions) or None


def parse_item(item: dict) -> Paper | None:
    """API 응답의 논문 한 건을 Paper 로 바꾼다. 제목이 없으면 None."""
    title = (item.get("display_name") or item.get("title") or "").strip()
    if not title:
        return None
    primary = item.get("primary_location") or {}
    source = primary.get("source") or {}
    best_oa = item.get("best_oa_location") or {}
    abstract = restore_abstract(item.get("abstract_inverted_index"))
    doi = clean_doi(item.get("doi"))
    lang = item.get("language")
    biblio = item.get("biblio") or {}
    return Paper(
        doi=doi,
        title=title,
        authors=[
            a["author"]["display_name"]
            for a in item.get("authorships") or []
            if (a.get("author") or {}).get("display_name")
        ],
        year=item.get("publication_year"),
        venue=source.get("display_name"),
        volume=clean_biblio(biblio.get("volume")),
        issue=clean_biblio(biblio.get("issue")),
        pages=page_range(biblio.get("first_page"), biblio.get("last_page")),
        publisher=source.get("host_organization_name") or None,
        abstract=abstract,
        language=lang if lang in ("ko", "en") else detect_language(title),
        citation_count=item.get("cited_by_count"),
        oa_pdf_url=best_oa.get("pdf_url") or None,
        landing_url=primary.get("landing_page_url")
        or best_oa.get("landing_page_url")
        or (f"https://doi.org/{doi}" if doi else item.get("id")),
        doc_type=TYPE_MAP.get(item.get("type") or "", "other"),
    )


class OpenAlexSource(BaseSource):
    """OpenAlex — 보조 검색 소스 (키 선택)."""

    name = "openalex"
    label = "OpenAlex"
    key_env = "OPENALEX_API_KEY"
    key_required = False
    min_interval_sec = 0.2  # 초당 10회 이하

    async def search(
        self, client: httpx.AsyncClient, query: str, filters: SearchFilters, limit: int = 25
    ) -> list[Paper]:
        """주제로 논문을 검색한다."""
        flt: list[str] = []
        if filters.year_from:
            flt.append(f"from_publication_date:{filters.year_from}-01-01")
        if filters.year_to:
            flt.append(f"to_publication_date:{filters.year_to}-12-31")
        if filters.oa_only:
            flt.append("is_oa:true")
        if filters.min_citations:
            flt.append(f"cited_by_count:>{filters.min_citations - 1}")
        params: dict[str, str | int] = {
            "search": query,
            "per_page": min(limit, 100),
            "select": SELECT,
        }
        if flt:
            params["filter"] = ",".join(flt)
        if self.api_key:
            params["api_key"] = self.api_key
        resp = await self._get(client, WORKS_URL, params=params)
        results = resp.json().get("results") or []
        return [p for p in (parse_item(i) for i in results) if p]

    async def related(
        self, client: httpx.AsyncClient, doi: str, direction: str, *, limit: int = 100
    ) -> tuple[list[Paper], int | None]:
        """인용 네트워크 한 쪽 (피인용 많은 순). 돌려주는 값: (논문 목록, 전체 편수).

        direction="citations" → filter=cites:W… (이 논문을 인용한 논문),
        direction="references" → filter=cited_by:W… (이 논문이 인용한 논문).
        """
        flt = {"citations": "cites", "references": "cited_by"}[direction]
        key = {"api_key": self.api_key} if self.api_key else {}
        resp = await self._get(
            client, f"{WORKS_URL}/doi:{doi}", params={"select": "id", **key}, allow_status=(404,)
        )
        if resp.status_code == 404:
            raise SourceError("OpenAlex 에서 이 논문(DOI)을 찾지 못했습니다.")
        work_id = (resp.json().get("id") or "").rsplit("/", 1)[-1]
        if not work_id:
            raise SourceError("OpenAlex 에서 이 논문의 ID 를 받지 못했습니다 — 잠시 후 다시 시도하세요.")
        resp = await self._get(client, WORKS_URL, params={
            "filter": f"{flt}:{work_id}", "per_page": min(limit, 100), "select": SELECT,
            "sort": "cited_by_count:desc", **key,
        })
        body = resp.json()
        papers = [p for p in (parse_item(i) for i in body.get("results") or []) if p]
        for p in papers:
            p.sources = [self.name]
        return papers, (body.get("meta") or {}).get("count")
