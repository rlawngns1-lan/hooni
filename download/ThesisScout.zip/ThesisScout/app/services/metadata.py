"""서지정보 보완: 서재 논문의 비어 있는 권·호·쪽·출판사를 Crossref 로 채운다 (인용 내보내기용)."""

from __future__ import annotations

import json
from dataclasses import dataclass, field

import httpx
from sqlmodel import select

from app.context import read_owner
from app.db import get_session
from app.models import LibraryItem, PaperRecord
from app.sources.base import HANGUL_RE, SourceError
from app.sources.crossref import CrossrefClient


@dataclass
class EnrichResult:
    """보완 결과 (화면 표시용)."""

    updated: int = 0  # 정보가 하나라도 채워진 논문 수
    checked: int = 0  # Crossref 에 물어본 논문 수
    notes: list[str] = field(default_factory=list)


def needs_enrichment(rec: PaperRecord) -> bool:
    """DOI 가 있고 아직 Crossref 로 확인하지 않은 논문인지."""
    return bool(rec.doi) and not rec.crossref_checked


def _apply(rec: PaperRecord, cr) -> bool:
    """Crossref 정보로 비어 있는 칸만 채운다. 바뀐 게 있으면 True."""
    changed = False
    for attr in ("venue", "volume", "issue", "pages", "publisher", "year"):
        if not getattr(rec, attr) and getattr(cr, attr):
            setattr(rec, attr, getattr(cr, attr))
            changed = True
    if rec.doc_type == "other" and cr.doc_type != "other":
        rec.doc_type = cr.doc_type
        changed = True
    # 국내 학술지 논문이 영문 제목으로 저장돼 있으면 Crossref 의 한글 제목을 대표로 쓴다
    if HANGUL_RE.search(cr.title) and not HANGUL_RE.search(rec.title):
        rec.title_alt, rec.title, rec.language = rec.title, cr.title, "ko"
        changed = True
    elif not rec.title_alt and cr.title_alt and cr.title_alt != rec.title:
        rec.title_alt = cr.title_alt
        changed = True
    # 영문 저자 이름은 Crossref 의 '성, 이름' 구분이 더 정확하다 (인용 양식에서 성·이니셜 처리에 필요)
    current = json.loads(rec.authors_json or "[]")
    korean = any(HANGUL_RE.search(a) for a in current)
    if cr.authors and not korean and len(cr.authors) >= len(current) and all("," in a for a in cr.authors):
        if cr.authors != current:
            rec.authors_json = json.dumps(cr.authors, ensure_ascii=False)
            changed = True
    return changed


async def enrich_records(
    paper_ids: list[int],
    *,
    client: CrossrefClient | None = None,
    db_url: str | None = None,
    owner: str | None = None,
) -> EnrichResult:
    """내 서재 논문들의 서지정보를 Crossref 로 보완해 DB 에 저장한다. 한 편이 실패해도 나머지는 계속.

    내 서재에 담긴 논문만 처리한다 (다른 사람이 임의의 논문 번호로 공용 논문 정보를 바꾸지 못하게).
    """
    owner = read_owner(owner)
    result = EnrichResult()
    if not owner:
        return result
    cr_client = client or CrossrefClient()
    with get_session(db_url) as s:
        mine = set(s.exec(
            select(LibraryItem.paper_id).where(LibraryItem.owner == owner, LibraryItem.paper_id.in_(paper_ids))
        ).all())
        targets = [(r.id, r.doi, r.title) for r in (s.get(PaperRecord, i) for i in mine)
                   if r and needs_enrichment(r)]
    async with httpx.AsyncClient(follow_redirects=True) as http:
        for paper_id, doi, title in targets:  # Crossref 공용 풀은 동시 1개 — 병렬로 바꾸지 말 것
            try:
                cr = await cr_client.fetch(http, doi)
            except SourceError as e:
                result.notes.append(f"{title[:40]} — {e}")
                continue
            result.checked += 1
            with get_session(db_url) as s:
                rec = s.get(PaperRecord, paper_id)  # 최신 상태를 다시 읽어 빈 칸만 채운다
                if rec is None:
                    continue
                if cr is not None and _apply(rec, cr):
                    result.updated += 1
                rec.crossref_checked = True
                s.add(rec)
                s.commit()
    return result
