"""인용 네트워크: 한 논문을 인용한 논문(후속 연구)과 그 논문이 인용한 논문(선행 연구)을 찾는다.

- Semantic Scholar: '영향력 있는 인용(isInfluential)' 표시를 준다. 결과는 최신순이라 피인용이 많은 논문은 앞부분만 보인다.
- OpenAlex: 피인용 많은 순으로 정렬해 주고 전체 편수(meta.count)를 알려 준다.
두 소스를 함께 불러 DOI·제목으로 병합한다. 한 소스가 실패해도 나머지 결과를 보여준다.
일부 출판사는 Semantic Scholar 에 참고문헌 목록 공개를 막아 두어(elided) OpenAlex 결과만 나올 수 있다.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass, field
from datetime import timedelta, timezone

import httpx

from app.db import get_session
from app.models import Paper, SearchCache, utcnow
from app.services.search import merge_papers
from app.sources.base import SourceError
from app.sources.openalex import OpenAlexSource
from app.sources.semantic_scholar import SemanticScholarSource
from config import settings

DIRECTIONS: dict[str, str] = {
    "citations": "이 논문을 인용한 논문 (후속 연구)",
    "references": "이 논문이 인용한 논문 (선행 연구·참고문헌)",
}


@dataclass
class NetworkResult:
    """인용 네트워크 결과."""

    papers: list[Paper] = field(default_factory=list)
    total: int | None = None  # 전체 편수 (OpenAlex 기준, 모르면 None)
    notes: list[str] = field(default_factory=list)  # 소스별 실패 안내
    cached: bool = False


def _key(doi: str, direction: str) -> str:
    return hashlib.sha1(f"network|{direction}|{doi}".encode("utf-8")).hexdigest()


def _cache_get(key: str, db_url: str | None) -> NetworkResult | None:
    with get_session(db_url) as s:
        row = s.get(SearchCache, key)
    if row is None:
        return None
    created = row.created_at if row.created_at.tzinfo else row.created_at.replace(tzinfo=timezone.utc)
    if utcnow() - created > timedelta(hours=settings.SEARCH_CACHE_HOURS):
        return None
    data = json.loads(row.payload)
    return NetworkResult([Paper.model_validate(d) for d in data["papers"]], data.get("total"), cached=True)


def _cache_put(key: str, res: NetworkResult, db_url: str | None) -> None:
    payload = json.dumps({"total": res.total, "papers": [p.model_dump() for p in res.papers]}, ensure_ascii=False)
    with get_session(db_url) as s:
        s.merge(SearchCache(key=key, source="network", payload=payload, created_at=utcnow()))
        s.commit()


async def _s2(src: SemanticScholarSource, client: httpx.AsyncClient, doi: str, direction: str, pages: int):
    out: list[Paper] = []
    offset: int | None = 0
    for _ in range(pages):
        batch, offset = await src.related(client, doi, direction, limit=100, offset=offset or 0)
        out += batch
        if offset is None:
            break
    return out


async def fetch_network(
    p: Paper,
    direction: str,
    *,
    s2: SemanticScholarSource | None = None,
    openalex: OpenAlexSource | None = None,
    s2_pages: int = 2,
    use_cache: bool = True,
    db_url: str | None = None,
) -> NetworkResult:
    """논문의 인용 네트워크 한 쪽을 가져온다 (피인용 많은 순). DOI 가 없으면 안내만 돌려준다."""
    if direction not in DIRECTIONS:
        raise ValueError(direction)
    if not p.doi:
        return NetworkResult(notes=["이 논문은 DOI 가 없어 인용 네트워크를 찾을 수 없습니다. Google Scholar 의 '인용' 링크를 이용해 보세요."])
    key = _key(p.doi, direction)
    if use_cache and (hit := _cache_get(key, db_url)):
        return hit

    if s2 is None or openalex is None:
        from app.sources import get_sources

        found = {src.name: src for src in get_sources()}
        s2 = s2 or found["semantic_scholar"]  # type: ignore[assignment]
        openalex = openalex or found["openalex"]  # type: ignore[assignment]

    async with httpx.AsyncClient(follow_redirects=True) as client:
        s2_res, oa_res = await asyncio.gather(
            _s2(s2, client, p.doi, direction, s2_pages),
            openalex.related(client, p.doi, direction, limit=100),
            return_exceptions=True,
        )
    res = NetworkResult()
    lists: list[list[Paper]] = []
    for label, r in (("OpenAlex", oa_res), ("Semantic Scholar", s2_res)):
        if isinstance(r, SourceError):
            res.notes.append(f"{label}: {r}")
        elif isinstance(r, BaseException):
            res.notes.append(f"{label}: 결과를 처리하지 못했습니다 ({type(r).__name__}) — 잠시 후 다시 시도하세요.")
        elif label == "OpenAlex":
            lists.append(r[0])
            res.total = r[1]
        else:
            lists.append(r)
    own = p.doi
    res.papers = [x for x in merge_papers(lists) if x.doi != own]
    res.papers.sort(key=lambda x: (x.citation_count or 0), reverse=True)
    if not res.papers and not res.notes and direction == "references":
        res.notes.append("참고문헌 목록이 공개되지 않은 논문입니다 (출판사 제한). 원문 PDF 의 참고문헌을 확인하세요.")
    if res.total is not None:
        res.total = max(res.total, len(res.papers))
    if use_cache and res.papers and not res.notes:
        _cache_put(key, res, db_url)
    return res


def clear_cache(doi: str, db_url: str | None = None) -> None:
    """이 논문의 인용 네트워크 캐시를 지운다 ([새로 불러오기])."""
    with get_session(db_url) as s:
        for direction in DIRECTIONS:
            row = s.get(SearchCache, _key(doi, direction))
            if row:
                s.delete(row)
        s.commit()


def sort_network(papers: list[Paper], how: str) -> list[Paper]:
    """정렬: citations(피인용 많은 순) / recent(최신순) / influential(영향력 있는 인용 먼저)."""
    if how == "recent":
        return sorted(papers, key=lambda x: (x.year or 0, x.citation_count or 0), reverse=True)
    if how == "influential":
        return sorted(papers, key=lambda x: (x.is_influential, x.citation_count or 0), reverse=True)
    return sorted(papers, key=lambda x: x.citation_count or 0, reverse=True)


def year_counts(papers: list[Paper]) -> dict[int, int]:
    """연도별 편수 (그래프용)."""
    out: dict[int, int] = {}
    for x in papers:
        if x.year:
            out[x.year] = out.get(x.year, 0) + 1
    return dict(sorted(out.items()))
