"""여러 소스 동시 검색 → 캐시 → 병합·중복제거 → 필터 → 정렬."""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import timedelta, timezone

import httpx
from sqlmodel import select

from app.db import get_session
from app.models import Paper, SearchCache, SearchHistory, utcnow
from app.services.journals import is_core_journal
from app.sources.base import HANGUL_RE, BaseSource, SearchFilters, SourceError
from config import settings

SORT_OPTIONS: dict[str, str] = {
    "relevance": "관련도",
    "citations": "피인용 수",
    "recent": "최신순",
}


@dataclass
class SourceStatus:
    """소스별 검색 결과 상태 (화면 표시용)."""

    name: str
    label: str
    state: str  # "ok" / "error" / "disabled"
    message: str = ""
    count: int = 0
    cached: bool = False


@dataclass
class SearchOutcome:
    """전체 검색 결과."""

    papers: list[Paper] = field(default_factory=list)
    statuses: list[SourceStatus] = field(default_factory=list)


# ---------------------------------------------------------------- 중복 제거·병합


def normalize_title(title: str) -> str:
    """제목 비교용 정규화: 소문자, 기호·공백 제거 (한글 유지)."""
    return re.sub(r"[^\w]", "", title.lower())


def _title_key(p: Paper) -> str:
    return f"{normalize_title(p.title)}|{p.year or ''}"


def paper_key(p: Paper) -> str:
    """논문 고유 키: DOI 가 있으면 DOI, 없으면 정규화한 제목|연도."""
    return f"doi:{p.doi}" if p.doi else f"t:{_title_key(p)}"


def _merge_into(base: Paper, other: Paper) -> None:
    """같은 논문의 두 레코드를 합친다 (비어 있는 정보는 채우고, 피인용은 큰 값, 한글 제목 우선)."""
    if HANGUL_RE.search(other.title) and not HANGUL_RE.search(base.title):
        # 다른 소스가 한글 제목을 알고 있으면 한글 제목을 대표로, 영문 제목은 보조로
        base.title_alt = base.title
        base.title = other.title
        base.language = "ko"
    elif not base.title_alt and other.title_alt and other.title_alt != base.title:
        base.title_alt = other.title_alt
    for attr in (
        "doi", "venue", "volume", "issue", "pages", "publisher",
        "abstract", "tldr", "language", "oa_pdf_url", "landing_url", "year",
    ):
        if not getattr(base, attr) and getattr(other, attr):
            setattr(base, attr, getattr(other, attr))
    if not base.authors and other.authors:
        base.authors = other.authors
    if other.citation_count is not None:
        base.citation_count = max(base.citation_count or 0, other.citation_count)
    if base.doc_type == "other" and other.doc_type != "other":
        base.doc_type = other.doc_type
    for s in other.sources:
        if s not in base.sources:
            base.sources.append(s)
    base.relevance += other.relevance
    base.is_influential = base.is_influential or other.is_influential


def merge_papers(results: list[list[Paper]]) -> list[Paper]:
    """소스별 결과 목록들을 하나로 병합한다.

    중복 판별: DOI 가 같으면 같은 논문, DOI 가 없으면 정규화한 제목+연도로 판별.
    관련도: 각 소스에서의 순위로 점수(1/(10+순위))를 매겨 합산 — 여러 소스에서 상위면 더 높다.
    """
    merged: list[Paper] = []
    by_doi: dict[str, Paper] = {}
    by_title: dict[str, Paper] = {}
    for papers in results:
        for rank, p in enumerate(papers):
            p = p.model_copy(deep=True)
            p.relevance = 1.0 / (10 + rank)
            existing = (by_doi.get(p.doi) if p.doi else None) or by_title.get(_title_key(p))
            if existing is not None and existing.doi and p.doi and existing.doi != p.doi:
                existing = None  # 제목이 같아도 DOI 가 다르면 다른 논문
            if existing is None:
                merged.append(p)
                existing = p
            else:
                _merge_into(existing, p)
            if existing.doi:
                by_doi[existing.doi] = existing
            by_title[_title_key(existing)] = existing
    for p in merged:
        p.is_core_journal = is_core_journal(p.venue)
    return merged


def apply_filters(papers: list[Paper], f: SearchFilters) -> list[Paper]:
    """필터 조건에 맞는 논문만 남긴다 (소스가 서버에서 거르지 못한 조건도 여기서 다시 확인)."""
    out = []
    for p in papers:
        if f.year_from and (p.year is None or p.year < f.year_from):
            continue
        if f.year_to and (p.year is None or p.year > f.year_to):
            continue
        if f.oa_only and not p.is_oa:
            continue
        # 피인용 수를 모르는 논문(국내 학술지 등)은 빼지 않는다 — 화면에 '피인용 정보 없음'으로 표시
        if f.min_citations and p.citation_count is not None and p.citation_count < f.min_citations:
            continue
        if f.languages and p.language not in f.languages:
            continue
        if f.doc_types and p.doc_type not in f.doc_types:
            continue
        out.append(p)
    return out


def sort_papers(papers: list[Paper], sort: str = "relevance") -> list[Paper]:
    """정렬: relevance(관련도) / citations(피인용 수) / recent(최신순)."""
    if sort == "citations":
        return sorted(papers, key=lambda p: (p.citation_count or 0, p.relevance), reverse=True)
    if sort == "recent":
        return sorted(papers, key=lambda p: (p.year or 0, p.relevance), reverse=True)
    return sorted(papers, key=lambda p: (p.relevance, p.citation_count or 0), reverse=True)


# ---------------------------------------------------------------- 캐시


def _cache_key(source: str, query: str, f: SearchFilters, limit: int) -> str:
    raw = f"{source}|{query.strip().lower()}|{f.cache_key()}|{limit}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def _cache_get(key: str, db_url: str | None) -> list[Paper] | None:
    with get_session(db_url) as s:
        row = s.get(SearchCache, key)
        if row is None:
            return None
        created = row.created_at
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        if utcnow() - created > timedelta(hours=settings.SEARCH_CACHE_HOURS):
            return None
        return [Paper.model_validate(d) for d in json.loads(row.payload)]


def _cache_put(key: str, source: str, papers: list[Paper], db_url: str | None) -> None:
    payload = json.dumps([p.model_dump() for p in papers], ensure_ascii=False)
    with get_session(db_url) as s:
        s.merge(SearchCache(key=key, source=source, payload=payload, created_at=utcnow()))
        s.commit()


# ---------------------------------------------------------------- 검색


async def _run_source(
    src: BaseSource,
    client: httpx.AsyncClient,
    query: str,
    f: SearchFilters,
    limit: int,
    use_cache: bool,
    db_url: str | None,
) -> tuple[list[Paper], SourceStatus]:
    """소스 하나를 검색한다. 실패해도 예외를 던지지 않고 상태로 돌려준다."""
    if not src.is_enabled():
        return [], SourceStatus(src.name, src.label, "disabled", src.disabled_reason())
    key = _cache_key(src.name, query, f, limit)
    if use_cache:
        cached = _cache_get(key, db_url)
        if cached is not None:
            return cached, SourceStatus(src.name, src.label, "ok", count=len(cached), cached=True)
    try:
        papers = await src.search(client, query, f, limit)
    except SourceError as e:
        return [], SourceStatus(src.name, src.label, "error", str(e))
    except Exception as e:  # 예상 못 한 오류도 다른 소스에 영향 주지 않게
        return [], SourceStatus(
            src.name, src.label, "error", f"{src.label} 결과를 처리하지 못했습니다 ({type(e).__name__})."
        )
    for p in papers:
        if src.name not in p.sources:
            p.sources.append(src.name)
    if use_cache:
        _cache_put(key, src.name, papers, db_url)
    return papers, SourceStatus(src.name, src.label, "ok", count=len(papers))


async def search_all(
    query: str,
    filters: SearchFilters,
    *,
    english_query: str | None = None,
    sources: list[BaseSource] | None = None,
    limit: int = 25,
    use_cache: bool = True,
    db_url: str | None = None,
) -> SearchOutcome:
    """모든 활성 소스를 동시에 검색해 병합·필터한 결과를 돌려준다 (정렬은 화면에서).

    영어 검색어가 따로 있으면 해외 소스(Semantic Scholar, OpenAlex)에는 영어 검색어를,
    한국 소스(KCI, RISS)에는 원래 검색어를 보낸다.
    """
    if sources is None:
        from app.sources import get_sources

        sources = get_sources()
    async with httpx.AsyncClient(follow_redirects=True) as client:
        tasks = []
        for src in sources:
            q = query if (src.korean or not english_query) else english_query
            tasks.append(_run_source(src, client, q, filters, limit, use_cache, db_url))
        results = await asyncio.gather(*tasks)
    papers = apply_filters(merge_papers([r[0] for r in results]), filters)
    return SearchOutcome(papers=papers, statuses=[r[1] for r in results])


def save_history(
    query: str, english_query: str | None, filters: SearchFilters, db_url: str | None = None,
    owner: str | None = None,
) -> None:
    """검색 기록을 저장한다. 공개 모드에서 로그인하지 않은 사람의 검색은 기록하지 않는다."""
    from app.context import read_owner

    owner = read_owner(owner)
    if not owner:
        return
    with get_session(db_url) as s:
        s.add(
            SearchHistory(
                owner=owner,
                query=query,
                expanded_keywords=json.dumps([english_query] if english_query else [], ensure_ascii=False),
                filters=json.dumps(filters.__dict__, ensure_ascii=False),
            )
        )
        s.commit()
