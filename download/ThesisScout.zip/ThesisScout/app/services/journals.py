"""핵심 저널 목록(config/core_journals.yaml) 읽기와 일치 판별."""

from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path

import yaml

from config import settings


def normalize_journal(name: str) -> str:
    """저널명을 비교용으로 정리한다 (소문자, 앞의 'the' 제거, 기호·공백 제거)."""
    name = name.strip().lower()
    name = re.sub(r"^the\s+", "", name)
    return re.sub(r"[^\w]", "", name)


@lru_cache(maxsize=2)
def load_core_journals(path: Path = settings.CORE_JOURNALS_PATH) -> frozenset[str]:
    """핵심 저널 목록을 정규화된 이름 집합으로 읽는다. 파일이 없거나 깨져 있으면 빈 집합."""
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        return frozenset()
    names: list[str] = []
    for value in data.values():
        if isinstance(value, list):
            names.extend(str(v) for v in value)
    return frozenset(normalize_journal(n) for n in names if n)


def is_core_journal(venue: str | None) -> bool:
    """저널명이 핵심 저널 목록에 있는지."""
    return bool(venue) and normalize_journal(venue) in load_core_journals()
