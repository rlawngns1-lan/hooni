"""내 서재: 논문 저장, 태그·메모·읽음 상태·프로젝트 관리.

모든 서재 데이터에는 소유자(owner)가 있다. 내 컴퓨터 모드에서는 'local' 한 명,
공개 모드에서는 로그인한 사람마다 다르다 (app/context.py). 다른 사람의 항목은 읽지도 고치지도 못한다.
논문 정보(PaperRecord)와 검색 캐시는 공개 자료라 함께 쓴다.
"""

from __future__ import annotations

import json

from sqlmodel import select

from app.context import read_owner, write_owner
from app.db import get_session
from app.models import READ_STATUS_LABELS, LibraryItem, Paper, PaperRecord, Project
from app.services.search import paper_key
from config import settings


class LibraryError(Exception):
    """사용자에게 보여줄 한국어 오류."""


NOT_FOUND = "서재에서 해당 논문을 찾을 수 없습니다 — 화면을 새로고침하세요."


# ---------------------------------------------------------------- 논문 (공용)


def record_to_paper(r: PaperRecord) -> Paper:
    """DB 레코드를 화면용 Paper 로 바꾼다."""
    return Paper(
        doi=r.doi,
        title=r.title,
        title_alt=r.title_alt,
        authors=json.loads(r.authors_json),
        year=r.year,
        venue=r.venue,
        volume=r.volume,
        issue=r.issue,
        pages=r.pages,
        publisher=r.publisher,
        abstract=r.abstract,
        tldr=r.tldr,
        language=r.language,
        citation_count=r.citation_count,
        oa_pdf_url=r.oa_pdf_url,
        landing_url=r.landing_url,
        doc_type=r.doc_type,
        sources=json.loads(r.sources_json),
        is_core_journal=r.is_core_journal,
    )


def upsert_paper(p: Paper, db_url: str | None = None) -> PaperRecord:
    """논문을 DB 에 저장하거나(처음) 최신 정보로 갱신한다(이미 있으면). 로컬 PDF 경로는 유지."""
    key = paper_key(p)
    with get_session(db_url) as s:
        rec = s.exec(select(PaperRecord).where(PaperRecord.key == key)).first()
        if rec is None:
            rec = PaperRecord(key=key, title=p.title)
        rec.doi, rec.title, rec.year = p.doi, p.title, p.year
        rec.title_alt = p.title_alt or rec.title_alt
        rec.authors_json = json.dumps(p.authors, ensure_ascii=False)
        rec.sources_json = json.dumps(p.sources, ensure_ascii=False)
        rec.venue = p.venue or rec.venue
        rec.volume = p.volume or rec.volume
        rec.issue = p.issue or rec.issue
        rec.pages = p.pages or rec.pages
        rec.publisher = p.publisher or rec.publisher
        rec.abstract = p.abstract or rec.abstract
        rec.tldr = p.tldr or rec.tldr
        rec.language, rec.citation_count, rec.doc_type = p.language, p.citation_count, p.doc_type
        rec.oa_pdf_url = p.oa_pdf_url or rec.oa_pdf_url
        rec.landing_url = p.landing_url or rec.landing_url
        rec.is_core_journal = p.is_core_journal
        s.add(rec)
        s.commit()
        s.refresh(rec)
        return rec


def set_local_pdf(paper_id: int, path: str, db_url: str | None = None) -> None:
    """내려받은 PDF 경로를 기록한다 (내 컴퓨터 모드 전용 — 공개 모드에서는 무시)."""
    if settings.PUBLIC_MODE:
        return
    with get_session(db_url) as s:
        rec = s.get(PaperRecord, paper_id)
        if rec:
            rec.local_pdf_path = path
            s.add(rec)
            s.commit()


def local_pdf_paths(db_url: str | None = None) -> dict[str, str]:
    """논문 키 → 내려받은 PDF 경로 (내 컴퓨터 모드 전용 — 공개 모드에서는 빈 값)."""
    if settings.PUBLIC_MODE:
        return {}
    with get_session(db_url) as s:
        rows = s.exec(select(PaperRecord).where(PaperRecord.local_pdf_path.is_not(None))).all()
        return {r.key: r.local_pdf_path for r in rows}


# ---------------------------------------------------------------- 서재 (사용자별)


def _own_item(s, item_id: int, owner: str) -> LibraryItem:
    item = s.get(LibraryItem, item_id)
    if item is None or item.owner != owner:
        raise LibraryError(NOT_FOUND)
    return item


def save_to_library(
    p: Paper, project_id: int | None = None, db_url: str | None = None, owner: str | None = None
) -> LibraryItem:
    """논문을 서재에 담는다. 이미 있으면 기존 항목을 돌려준다."""
    owner = write_owner(owner)
    if project_id is not None:
        with get_session(db_url) as s:
            proj = s.get(Project, project_id)
            if proj is None or proj.owner != owner:
                raise LibraryError("해당 프로젝트를 찾을 수 없습니다 — 화면을 새로고침하세요.")
    rec = upsert_paper(p, db_url)
    with get_session(db_url) as s:
        item = s.exec(
            select(LibraryItem).where(LibraryItem.owner == owner, LibraryItem.paper_id == rec.id)
        ).first()
        if item is None:
            item = LibraryItem(owner=owner, paper_id=rec.id, project_id=project_id)
            s.add(item)
            s.commit()
            s.refresh(item)
        return item


def saved_keys(db_url: str | None = None, owner: str | None = None) -> set[str]:
    """서재에 담긴 논문들의 키 집합 (검색 화면의 '저장됨' 표시용). 로그인 전이면 빈 집합."""
    owner = read_owner(owner)
    if not owner:
        return set()
    with get_session(db_url) as s:
        rows = s.exec(
            select(PaperRecord.key)
            .join(LibraryItem, LibraryItem.paper_id == PaperRecord.id)
            .where(LibraryItem.owner == owner)
        ).all()
        return set(rows)


def get_tags(item: LibraryItem) -> list[str]:
    """항목의 태그 목록."""
    return json.loads(item.tags_json or "[]")


def parse_tags(text: str) -> list[str]:
    """'동맹, 억지 , #확장억제' → ['동맹', '억지', '확장억제'] (중복 제거, 순서 유지)."""
    out: list[str] = []
    for t in text.replace("#", "").split(","):
        t = t.strip()
        if t and t not in out:
            out.append(t)
    return out


def update_item(
    item_id: int,
    *,
    tags: list[str] | None = None,
    note: str | None = None,
    read_status: str | None = None,
    project_id: int | None | str = "keep",
    db_url: str | None = None,
    owner: str | None = None,
) -> None:
    """서재 항목의 태그·메모·읽음 상태·프로젝트를 바꾼다 (project_id=None 이면 프로젝트 해제)."""
    owner = write_owner(owner)
    if read_status is not None and read_status not in READ_STATUS_LABELS:
        raise LibraryError(f"알 수 없는 읽음 상태입니다: {read_status}")
    with get_session(db_url) as s:
        item = _own_item(s, item_id, owner)
        if project_id not in ("keep", None):
            proj = s.get(Project, project_id)
            if proj is None or proj.owner != owner:
                raise LibraryError("해당 프로젝트를 찾을 수 없습니다 — 화면을 새로고침하세요.")
        if tags is not None:
            item.tags_json = json.dumps(tags, ensure_ascii=False)
        if note is not None:
            item.note = note
        if read_status is not None:
            item.read_status = read_status
        if project_id != "keep":
            item.project_id = project_id  # type: ignore[assignment]
        s.add(item)
        s.commit()


def remove_from_library(item_id: int, db_url: str | None = None, owner: str | None = None) -> None:
    """서재에서 뺀다 (내려받은 PDF 파일은 지우지 않는다)."""
    owner = write_owner(owner)
    with get_session(db_url) as s:
        item = s.get(LibraryItem, item_id)
        if item and item.owner == owner:
            s.delete(item)
            s.commit()


def list_items(
    *,
    project_id: int | None = None,
    read_status: str | None = None,
    tag: str | None = None,
    text: str | None = None,
    db_url: str | None = None,
    owner: str | None = None,
) -> list[tuple[LibraryItem, PaperRecord]]:
    """서재 목록 (최근 추가 순). 조건을 주면 그에 맞는 것만. 로그인 전이면 빈 목록."""
    owner = read_owner(owner)
    if not owner:
        return []
    with get_session(db_url) as s:
        q = (
            select(LibraryItem, PaperRecord)
            .join(PaperRecord, LibraryItem.paper_id == PaperRecord.id)
            .where(LibraryItem.owner == owner)
        )
        if project_id is not None:
            q = q.where(LibraryItem.project_id == project_id)
        if read_status:
            q = q.where(LibraryItem.read_status == read_status)
        rows = list(s.exec(q.order_by(LibraryItem.added_at.desc())).all())
    if tag:
        rows = [r for r in rows if tag in get_tags(r[0])]
    if text:
        t = text.lower()
        rows = [
            r for r in rows
            if t in r[1].title.lower() or t in (r[0].note or "").lower() or t in r[1].authors_json.lower()
        ]
    return rows


def all_tags(db_url: str | None = None, owner: str | None = None) -> list[str]:
    """서재에 쓰인 모든 태그 (가나다순)."""
    owner = read_owner(owner)
    if not owner:
        return []
    with get_session(db_url) as s:
        items = s.exec(select(LibraryItem).where(LibraryItem.owner == owner)).all()
    return sorted({t for i in items for t in get_tags(i)})


# ---------------------------------------------------------------- 프로젝트 (사용자별)


def create_project(name: str, description: str = "", db_url: str | None = None, owner: str | None = None) -> Project:
    """프로젝트를 만든다. 같은 이름이 있으면 오류."""
    owner = write_owner(owner)
    name = name.strip()
    if not name:
        raise LibraryError("프로젝트 이름을 입력하세요.")
    with get_session(db_url) as s:
        if s.exec(select(Project).where(Project.owner == owner, Project.name == name)).first():
            raise LibraryError(f"'{name}' 프로젝트가 이미 있습니다. 다른 이름을 쓰세요.")
        proj = Project(owner=owner, name=name, description=description.strip())
        s.add(proj)
        s.commit()
        s.refresh(proj)
        return proj


def list_projects(db_url: str | None = None, owner: str | None = None) -> list[Project]:
    """프로젝트 목록 (만든 순서)."""
    owner = read_owner(owner)
    if not owner:
        return []
    with get_session(db_url) as s:
        return list(s.exec(select(Project).where(Project.owner == owner).order_by(Project.id)).all())


def delete_project(project_id: int, db_url: str | None = None, owner: str | None = None) -> None:
    """프로젝트를 지운다. 안에 있던 논문은 서재에 남고 '프로젝트 없음'이 된다."""
    owner = write_owner(owner)
    with get_session(db_url) as s:
        proj = s.get(Project, project_id)
        if proj is None or proj.owner != owner:
            return
        for item in s.exec(
            select(LibraryItem).where(LibraryItem.owner == owner, LibraryItem.project_id == project_id)
        ).all():
            item.project_id = None
            s.add(item)
        s.delete(proj)
        s.commit()


def delete_all_user_data(db_url: str | None = None, owner: str | None = None) -> dict[str, int]:
    """이 사용자의 서재·프로젝트·검색 기록·저장된 검색을 모두 지운다 (공개 모드의 '내 데이터 지우기')."""
    from app.models import SavedSearch, SearchHistory

    owner = write_owner(owner)
    counts: dict[str, int] = {}
    with get_session(db_url) as s:
        for model in (LibraryItem, Project, SearchHistory, SavedSearch):
            rows = s.exec(select(model).where(model.owner == owner)).all()
            for r in rows:
                s.delete(r)
            counts[model.__name__] = len(rows)
            s.flush()  # 서재 항목을 먼저 지워야 프로젝트를 지울 수 있다 (외래 키)
        s.commit()
    return counts
