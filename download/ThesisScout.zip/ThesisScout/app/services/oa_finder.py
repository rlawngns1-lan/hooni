"""논문의 합법적 OA PDF 주소 찾기: 검색 결과 → Unpaywall → CORE 순서."""

from __future__ import annotations

from dataclasses import dataclass, field

import httpx

from app.models import Paper
from app.sources.base import SourceError
from app.sources.core import CoreClient
from app.sources.unpaywall import UnpaywallClient


@dataclass
class OAResult:
    """찾은 결과. url 이 None 이면 못 찾음. notes 는 화면에 보여줄 안내."""

    url: str | None = None
    found_by: str | None = None
    notes: list[str] = field(default_factory=list)


async def find_oa_pdf(p: Paper, *, clients: list | None = None) -> OAResult:
    """이미 아는 OA 주소가 있으면 그것을, 없으면 DOI 로 Unpaywall·CORE 에 차례로 물어본다."""
    if p.oa_pdf_url:
        return OAResult(p.oa_pdf_url, "검색 결과")
    result = OAResult()
    if not p.doi:
        result.notes.append("DOI 가 없어 무료 PDF 를 추가로 찾을 수 없습니다.")
        return result
    clients = clients if clients is not None else [UnpaywallClient(), CoreClient()]
    async with httpx.AsyncClient(follow_redirects=True) as http:
        for c in clients:
            if not c.is_enabled():
                result.notes.append(c.disabled_reason())
                continue
            try:
                url = await c.find_pdf(http, p.doi)
            except SourceError as e:
                result.notes.append(str(e))
                continue
            if url:
                return OAResult(url, c.label, result.notes)
            result.notes.append(f"{c.label}: 공개된 PDF 가 없습니다.")
    return result


def oa_lookup_available() -> bool:
    """Unpaywall·CORE 중 하나라도 쓸 수 있는지."""
    return UnpaywallClient().is_enabled() or CoreClient().is_enabled()
