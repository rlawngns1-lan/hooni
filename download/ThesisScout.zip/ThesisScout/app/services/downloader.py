"""합법적 Open Access PDF 다운로드.

규칙 (CLAUDE.md 7장):
- 다운로드 주소는 공식 API 가 알려준 OA 주소만 쓴다 (Semantic Scholar openAccessPdf,
  OpenAlex best_oa_location, Unpaywall, CORE). 출판사 페이지를 긁어 PDF 를 찾지 않는다.
- 리디렉트를 따라간 최종 주소도 http(s) 인지 확인하고, 내용이 실제 PDF(%PDF 로 시작)인지 검사한다.
  (OA 주소가 로그인 페이지·HTML 로 바뀌어 있으면 저장하지 않고 '논문 페이지'로 안내한다.)
"""

from __future__ import annotations

import asyncio
import ipaddress
import re
from pathlib import Path
from urllib.parse import urljoin

import httpx

from app.models import Paper
from app.sources.base import HANGUL_RE, USER_AGENT
from config import settings

MAX_BYTES = 80 * 1024 * 1024  # 80MB 넘는 파일은 받지 않음
MAX_REDIRECTS = 5
INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


class DownloadError(Exception):
    """사용자에게 보여줄 한국어 오류."""


def first_author_surname(p: Paper) -> str:
    """제1저자 성. 한글 이름은 첫 글자, 영문 이름은 마지막 단어."""
    if not p.authors:
        return "저자미상"
    name = p.authors[0].strip()
    if "," in name:  # 'Kim, Jane' 형식
        return name.split(",")[0].strip() or "저자미상"
    if HANGUL_RE.match(name):
        return name.replace(" ", "")[:1]
    parts = name.split()
    return parts[-1] if parts else "저자미상"


def make_filename(p: Paper, title_chars: int = 40) -> str:
    """'{연도}_{제1저자성}_{제목앞부분}.pdf' 형식의 윈도우에서 안전한 파일 이름."""
    title = INVALID_CHARS.sub("", p.title)
    title = re.sub(r"\s+", "_", title.strip())[:title_chars].rstrip("._")
    surname = INVALID_CHARS.sub("", first_author_surname(p)).replace(" ", "")
    return f"{p.year or '연도미상'}_{surname}_{title or '제목없음'}.pdf"


async def download_pdf(
    url: str,
    filename: str,
    *,
    dest_dir: Path = settings.PAPERS_DIR,
    client: httpx.AsyncClient | None = None,
    retries: int = settings.HTTP_MAX_RETRIES,
    backoff_sec: float = 1.0,
) -> Path:
    """OA PDF 를 내려받아 저장 경로를 돌려준다. 같은 이름 파일이 이미 있으면 그대로 돌려준다."""
    if settings.PUBLIC_MODE:  # 인터넷 공개판은 서버에 PDF 를 모아 두지 않는다
        raise DownloadError("인터넷 공개판에서는 PDF 를 서버에 저장하지 않습니다 — '무료 PDF' 링크로 바로 여세요.")
    if not url.lower().startswith(("http://", "https://")):
        raise DownloadError("올바른 PDF 주소가 아닙니다.")
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / filename
    if dest.exists() and dest.stat().st_size > 0:
        return dest

    own_client = client is None
    client = client or httpx.AsyncClient(follow_redirects=True)
    try:
        last_err = "PDF 를 내려받지 못했습니다 — 잠시 후 다시 시도하세요."
        for attempt in range(retries + 1):
            try:
                return await _fetch(client, url, dest)
            except DownloadError:
                raise
            except _Retryable as e:
                last_err = str(e)
            except httpx.TimeoutException:
                last_err = "PDF 서버 응답 시간이 초과됐습니다 — 잠시 후 다시 시도하세요."
            except httpx.HTTPError:
                last_err = "PDF 서버에 연결할 수 없습니다 — 인터넷 연결을 확인하세요."
            if attempt < retries:
                await asyncio.sleep(backoff_sec * (2**attempt))
        raise DownloadError(last_err)
    finally:
        if own_client:
            await client.aclose()


class _Retryable(Exception):
    pass


def check_url_safe(url: httpx.URL) -> None:
    """http(s) 이고, 내 컴퓨터·내부망(localhost, 사설 IP) 주소가 아닌지 확인한다."""
    if url.scheme not in ("http", "https"):
        raise DownloadError("PDF 주소가 이상한 곳으로 연결되어 받지 않았습니다.")
    host = (url.host or "").lower()
    if not host or host == "localhost" or host.endswith(".localhost"):
        raise DownloadError("PDF 주소가 내 컴퓨터 주소로 연결되어 받지 않았습니다.")
    try:
        ip = ipaddress.ip_address(host.strip("[]"))
    except ValueError:
        return  # 도메인 이름
    if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
        raise DownloadError("PDF 주소가 내부망 주소로 연결되어 받지 않았습니다.")


async def _fetch(client: httpx.AsyncClient, url: str, dest: Path) -> Path:
    """한 번 내려받기를 시도한다. 리디렉트는 한 단계씩 직접 따라가며 매번 주소를 검사한다."""
    headers = {"User-Agent": USER_AGENT, "Accept": "application/pdf"}
    current = httpx.URL(url)
    for _ in range(MAX_REDIRECTS + 1):
        check_url_safe(current)
        req = client.build_request("GET", current, headers=headers, timeout=settings.HTTP_TIMEOUT_SEC)
        resp = await client.send(req, stream=True, follow_redirects=False)
        if resp.is_redirect and resp.headers.get("Location"):
            await resp.aclose()
            current = httpx.URL(urljoin(str(current), resp.headers["Location"]))
            continue
        try:
            return await _save(resp, dest)
        finally:
            await resp.aclose()
    raise DownloadError("PDF 주소가 너무 여러 번 다른 곳으로 넘어가서 받지 않았습니다.")


async def _save(resp: httpx.Response, dest: Path) -> Path:
    """응답이 PDF 이면 파일로 저장한다."""
    if resp.status_code in (429, 500, 502, 503, 504):
        raise _Retryable(f"PDF 서버가 일시적으로 응답하지 않습니다({resp.status_code}) — 잠시 후 다시 시도하세요.")
    if resp.status_code >= 400:
        raise DownloadError(
            f"PDF 를 받을 수 없습니다({resp.status_code}) — 공개가 중단됐을 수 있습니다. "
            "'논문 페이지'나 도서관 링크로 확인하세요."
        )
    tmp = dest.with_suffix(".part")
    size = 0
    first = b""
    try:
        with tmp.open("wb") as f:
            async for chunk in resp.aiter_bytes():
                if not first:
                    first = chunk[:5]
                    if not first.startswith(b"%PDF"):
                        raise DownloadError(
                            "이 링크는 PDF 파일이 아니라 웹페이지로 연결됩니다 — "
                            "'무료 PDF'나 '논문 페이지' 버튼으로 직접 확인하세요."
                        )
                size += len(chunk)
                if size > MAX_BYTES:
                    raise DownloadError("PDF 가 너무 큽니다(80MB 초과) — '무료 PDF' 버튼으로 직접 받으세요.")
                f.write(chunk)
        if size == 0:
            raise DownloadError("빈 파일이 내려왔습니다 — 잠시 후 다시 시도하세요.")
        tmp.replace(dest)
        return dest
    finally:
        if tmp.exists():
            tmp.unlink()
