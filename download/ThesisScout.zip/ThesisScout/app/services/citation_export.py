"""인용 내보내기: BibTeX, RIS(Zotero·EndNote), APA 7판, 한국정치학회(저자-연도) 양식.

참고한 규칙
- BibTeX: 표준 항목(@article 등)과 필드. 제목은 대소문자 유지를 위해 {{...}} 로 감싼다.
- RIS: TY~ER 태그 형식 (Zotero·EndNote 가져오기용).
- APA 7판: 저자(성, 이니셜) → (연도) → 제목 → *저널*, *권*(호), 쪽 → DOI. 저자 21명 이상이면 19명 + … + 마지막 저자.
  제목의 문장형 대소문자(sentence case) 변환은 고유명사 판별이 어려워 하지 않는다 (원제목 그대로).
- 한국정치학회 양식: 공식 집필요강을 직접 확인하지 못해(2026-11-26, 학회 사이트 접속 불가),
  정치학계에서 널리 쓰는 저자-연도 형식(예: 이종은. 2000. “민주시민의 덕성”. 『한국정치학회보』 34집 1호. 121-122.)을
  따른다. 투고 전 학회의 최신 원고작성요강과 반드시 대조해야 한다 (화면에도 안내).
"""

from __future__ import annotations

import html
import re

from app.models import Paper
from app.sources.base import HANGUL_RE

FORMATS: dict[str, dict[str, str]] = {
    "bibtex": {"label": "BibTeX (LaTeX·Zotero)", "ext": "bib", "mime": "application/x-bibtex"},
    "ris": {"label": "RIS (Zotero·EndNote·Mendeley)", "ext": "ris", "mime": "application/x-research-info-systems"},
    "apa": {"label": "APA 7판", "ext": "txt", "mime": "text/plain"},
    "kpsa": {"label": "한국정치학회 양식 (저자-연도)", "ext": "txt", "mime": "text/plain"},
}
STYLE_FORMATS = ("apa", "kpsa")  # 사람이 읽는 참고문헌 목록 (기울임꼴 있음)

Segment = tuple[str, bool]  # (글자, 기울임 여부)
PARTICLES = {"van", "von", "de", "da", "del", "della", "di", "du", "le", "la", "bin", "al", "el", "der", "den", "ter"}


# ---------------------------------------------------------------- 이름 처리


def is_korean_text(s: str | None) -> bool:
    """한글이 들어 있는지."""
    return bool(s and HANGUL_RE.search(s))


def is_korean_paper(p: Paper) -> bool:
    """한국어 문헌인지 (언어 정보 또는 제목의 한글로 판단)."""
    return p.language == "ko" or is_korean_text(p.title)


def split_name(name: str) -> tuple[str, str]:
    """이름을 (성, 이름) 으로 나눈다. 'Kim, Jane' / 'Jane Q. Kim' / 'Ludwig van Beethoven' / '홍길동'."""
    name = re.sub(r"\s+", " ", name).strip()
    if "," in name:
        family, given = name.split(",", 1)
        return family.strip(), given.strip()
    if is_korean_text(name):
        return name.replace(" ", ""), ""
    parts = name.split(" ")
    if len(parts) == 1:
        return parts[0], ""
    i = len(parts) - 1
    while i > 1 and parts[i - 1].lower() in PARTICLES:  # van, de 같은 접두어는 성에 포함
        i -= 1
    return " ".join(parts[i:]), " ".join(parts[:i])


def initials(given: str) -> str:
    """'Jane Quincy' → 'J. Q.', 'Jae-Hoon' → 'J.-H.'"""
    out = []
    for part in given.replace(".", ". ").split():
        sub = [s for s in part.split("-") if s]
        if sub:
            out.append("-".join(f"{s[0].upper()}." for s in sub))
    return " ".join(out)


def _family_given(name: str) -> str:
    """'성, 이름' 형식 (한글 이름은 그대로)."""
    family, given = split_name(name)
    return f"{family}, {given}" if given else family


# ---------------------------------------------------------------- 공통


def _end(s: str) -> str:
    """문장 끝에 마침표 (이미 . ? ! 로 끝나면 그대로)."""
    s = s.strip()
    return s if s.endswith((".", "?", "!")) else s + "."


def _doi_url(p: Paper) -> str | None:
    return f"https://doi.org/{p.doi}" if p.doi else None


def _sort_key(p: Paper) -> tuple:
    """참고문헌 정렬: 한국어 문헌 먼저(가나다), 그다음 외국 문헌(알파벳), 같은 저자는 연도순."""
    first = split_name(p.authors[0])[0] if p.authors else p.title
    return (0 if is_korean_paper(p) else 1, first.lower(), p.year or 9999, p.title.lower())


def missing_info(p: Paper) -> list[str]:
    """인용에 필요한데 비어 있는 정보 (화면 경고용)."""
    miss = []
    if not p.authors:
        miss.append("저자")
    if not p.year:
        miss.append("연도")
    if p.doc_type == "journal":
        if not p.venue:
            miss.append("학술지명")
        if not p.volume:
            miss.append("권")
        if not p.pages:
            miss.append("쪽")
    return miss


# ---------------------------------------------------------------- BibTeX

_BIB_ESCAPE = {"&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_"}


def _bib(s: str) -> str:
    """BibTeX 특수문자 처리 (중괄호는 짝이 깨질 수 있어 제거)."""
    s = s.replace("{", "").replace("}", "").replace("\\", "")
    return "".join(_BIB_ESCAPE.get(c, c) for c in s)


def bibtex_key(p: Paper, used: set[str]) -> str:
    """인용 키: 성 + 연도 + 제목 첫 단어 (영문만, 예: waltz1979theory). 겹치면 a, b, … 를 붙인다."""
    surname = split_name(p.authors[0])[0] if p.authors else ""
    surname = re.sub(r"[^a-z]", "", surname.lower()) or "ref"
    words = [w for w in re.findall(r"[a-zA-Z]+", p.title.lower()) if w not in {"a", "an", "the", "on", "of"}]
    base = f"{surname}{p.year or 'nd'}{words[0] if words else ''}"
    key, n = base, 0
    while key in used:
        key = base + "abcdefghijklmnopqrstuvwxyz"[n % 26] * (n // 26 + 1)
        n += 1
    used.add(key)
    return key


def to_bibtex(papers: list[Paper]) -> str:
    """BibTeX 문자열."""
    used: set[str] = set()
    entries = []
    for p in papers:
        kind, venue_field = {
            "journal": ("article", "journal"),
            "thesis": ("thesis", "school"),
            "report": ("techreport", "institution"),
        }.get(p.doc_type, ("misc", "howpublished"))
        fields: list[tuple[str, str]] = []
        if p.authors:
            fields.append(("author", " and ".join(
                f"{{{_bib(a)}}}" if is_korean_text(a) else _bib(_family_given(a)) for a in p.authors
            )))
        fields.append(("title", f"{{{_bib(p.title)}}}"))
        if p.venue:
            fields.append((venue_field, _bib(p.venue)))
        if p.year:
            fields.append(("year", str(p.year)))
        if p.volume:
            fields.append(("volume", _bib(p.volume)))
        if p.issue:
            fields.append(("number", _bib(p.issue)))
        if p.pages:
            fields.append(("pages", _bib(p.pages).replace("-", "--")))
        if p.publisher and p.doc_type != "report":
            fields.append(("publisher", _bib(p.publisher)))
        if p.doi:
            fields.append(("doi", p.doi))
        elif p.landing_url:
            fields.append(("url", p.landing_url))
        if is_korean_paper(p):
            fields.append(("langid", "korean"))
        body = ",\n".join(f"  {k} = {{{v}}}" for k, v in fields)
        entries.append(f"@{kind}{{{bibtex_key(p, used)},\n{body}\n}}")
    return "\n\n".join(entries) + "\n"


# ---------------------------------------------------------------- RIS


def to_ris(papers: list[Paper], include_abstract: bool = False) -> str:
    """RIS 문자열 (줄바꿈은 CRLF — EndNote 호환). 초록은 요청할 때만 (개인 서지관리용)."""
    lines: list[str] = []
    for p in papers:
        ty = {"journal": "JOUR", "thesis": "THES", "report": "RPRT"}.get(p.doc_type, "GEN")
        lines.append(f"TY  - {ty}")
        for a in p.authors:
            lines.append(f"AU  - {_family_given(a)}")
        lines.append(f"TI  - {p.title}")
        if p.venue:
            lines.append(f"{'PB' if p.doc_type == 'thesis' else 'T2'}  - {p.venue}")
        if p.year:
            lines.append(f"PY  - {p.year}")
        if p.volume:
            lines.append(f"VL  - {p.volume}")
        if p.issue:
            lines.append(f"IS  - {p.issue}")
        if p.pages:
            sp, _, ep = p.pages.partition("-")
            lines.append(f"SP  - {sp}")
            if ep:
                lines.append(f"EP  - {ep}")
        if p.publisher and p.doc_type != "thesis":
            lines.append(f"PB  - {p.publisher}")
        if p.doi:
            lines.append(f"DO  - {p.doi}")
        if p.landing_url or p.doi:
            lines.append(f"UR  - {p.landing_url or _doi_url(p)}")
        if p.language:
            lines.append(f"LA  - {p.language}")
        if include_abstract and p.abstract:
            abstract = re.sub(r"\s+", " ", p.abstract).strip()
            lines.append(f"AB  - {abstract}")
        lines.append("ER  - ")
        lines.append("")
    return "\r\n".join(lines)


# ---------------------------------------------------------------- APA 7판


def apa_author(name: str) -> str:
    """APA 저자: 'Waltz, K. N.' (한글 이름은 그대로)."""
    family, given = split_name(name)
    if not given:
        return family
    return f"{family}, {initials(given)}"


def apa_authors(authors: list[str]) -> str:
    """APA 저자 목록: 1명 A / 2명 A, & B / 3~20명 A, B, & C / 21명 이상 19명, . . . 마지막."""
    names = [apa_author(a) for a in authors]
    if len(names) == 1:
        return names[0]
    if len(names) <= 20:
        return ", ".join(names[:-1]) + ", & " + names[-1]
    return ", ".join(names[:19]) + ", . . . " + names[-1]


def apa_segments(p: Paper) -> list[Segment]:
    """APA 7판 참고문헌 한 줄 (기울임 표시 포함)."""
    seg: list[Segment] = []
    year = f"({p.year})." if p.year else "(n.d.)."
    title = _end(p.title)
    if p.authors:
        seg.append((f"{_end(apa_authors(p.authors))} {year} ", False))
    if p.doc_type == "journal":
        if p.authors:
            seg.append((title + " ", False))
        else:
            seg.append((f"{title} {year} ", False))
        if p.venue:
            seg.append((p.venue, True))
            if p.volume:
                seg.append((", ", False))
                seg.append((p.volume, True))
                if p.issue:
                    seg.append((f"({p.issue})", False))
            if p.pages:
                seg.append((f", {p.pages}", False))
            seg.append((". ", False))
    else:
        bare = p.title.rstrip(".")
        seg.append((bare, True))
        if not p.authors:
            seg.append((f" {year}", False))
        if p.doc_type == "thesis":
            kind = "학위논문" if is_korean_paper(p) else "Thesis"
            seg.append((f" [{kind}{', ' + p.venue if p.venue else ''}]", False))
            seg.append((". ", False))
        else:
            seg.append((". ", False))
            where = p.publisher or p.venue
            if where:
                seg.append((_end(where) + " ", False))
    link = _doi_url(p) or (p.landing_url if p.doc_type != "journal" else None)
    if link:
        seg.append((link, False))
    return _strip_segments(seg)


# ---------------------------------------------------------------- 한국정치학회 양식


def kpsa_authors(authors: list[str], korean: bool) -> str:
    """국문: 홍길동·김철수 (4명 이상 '홍길동 외'). 영문: 첫 저자만 '성, 이름', 나머지 '이름 성', 마지막은 and."""
    if korean:
        names = [split_name(a)[0] if is_korean_text(a) else a for a in authors]
        return f"{names[0]} 외" if len(names) > 3 else "·".join(names)
    first = _family_given(authors[0])
    rest = []
    for a in authors[1:]:
        family, given = split_name(a)
        rest.append(f"{given} {family}".strip())
    if len(authors) > 6:
        return f"{first} et al"
    if not rest:
        return first
    if len(rest) == 1:
        return f"{first} and {rest[0]}"
    return ", ".join([first, *rest[:-1]]) + f", and {rest[-1]}"


def kpsa_segments(p: Paper) -> list[Segment]:
    """한국정치학회(저자-연도) 양식 참고문헌 한 줄."""
    ko = is_korean_paper(p)
    seg: list[Segment] = []
    if p.authors:
        seg.append((_end(kpsa_authors(p.authors, ko)) + " ", False))
    seg.append((f"{p.year or ('연도미상' if ko else 'n.d.')}. ", False))
    title = p.title.rstrip(".")
    if p.doc_type in ("journal", "thesis"):
        seg.append((f"“{title}”. ", False))
    if p.doc_type == "journal":
        if ko:
            vol = " ".join(x for x in (f"{p.volume}집" if p.volume else "", f"{p.issue}호" if p.issue else "") if x)
            seg.append((f"『{p.venue}』" if p.venue else "", False))
            seg.append(((f" {vol}" if vol else "") + ". ", False))
        else:
            if p.venue:
                seg.append((p.venue, True))
            vi = (p.volume or "") + (f"({p.issue})" if p.issue else "")
            seg.append(((f" {vi}" if vi else "") + (", " if p.pages else ". "), False))
        if p.pages:
            seg.append((_end(p.pages) + " ", False))
    elif p.doc_type == "thesis":
        where = p.venue or p.publisher or ""
        seg.append((_end(f"{where} 학위논문" if ko else f"Thesis, {where}".rstrip(", ")) + " ", False))
    else:
        seg.append((f"『{title}』. " if ko else "", False))
        if not ko:
            seg.append((title, True))
            seg.append((". ", False))
        where = p.publisher or p.venue
        if where:
            seg.append((_end(where) + " ", False))
    return _strip_segments(seg)


# ---------------------------------------------------------------- 출력


def _strip_segments(seg: list[Segment]) -> list[Segment]:
    """빈 조각을 빼고 끝 공백을 정리한다."""
    seg = [(t, i) for t, i in seg if t]
    if seg:
        t, i = seg[-1]
        seg[-1] = (t.rstrip(), i)
    return seg


def style_entries(papers: list[Paper], fmt: str) -> list[list[Segment]]:
    """APA / 한국정치학회 참고문헌 목록 (정렬 포함)."""
    builder = apa_segments if fmt == "apa" else kpsa_segments
    return [builder(p) for p in sorted(papers, key=_sort_key)]


def segments_to_plain(seg: list[Segment]) -> str:
    """기울임 없는 일반 텍스트."""
    return "".join(t for t, _ in seg)


def segments_to_markdown(seg: list[Segment]) -> str:
    """화면 미리보기용 마크다운 (기울임은 *…*)."""
    def esc(t: str) -> str:
        return re.sub(r"([\\*_$\[\]<>`])", r"\\\1", t)

    return "".join(f"*{esc(t)}*" if it else esc(t) for t, it in seg)


def segments_to_html(seg: list[Segment]) -> str:
    """HTML (기울임은 <i>)."""
    return "".join(f"<i>{html.escape(t)}</i>" if it else html.escape(t) for t, it in seg)


def export_text(papers: list[Paper], fmt: str, include_abstract: bool = False) -> str:
    """내보내기 파일 내용 (BibTeX·RIS 는 그 형식, APA·학회 양식은 일반 텍스트)."""
    if fmt == "bibtex":
        return to_bibtex(papers)
    if fmt == "ris":
        return to_ris(papers, include_abstract)
    if fmt in STYLE_FORMATS:
        return "\n\n".join(segments_to_plain(s) for s in style_entries(papers, fmt)) + "\n"
    raise ValueError(f"알 수 없는 형식: {fmt}")


def export_html(papers: list[Paper], fmt: str) -> str:
    """APA·학회 양식을 기울임꼴이 살아 있는 HTML 문서로 (워드에 붙여넣기용, 내어쓰기 적용)."""
    title = FORMATS[fmt]["label"]
    body = "\n".join(
        f'<p style="padding-left:2em;text-indent:-2em;margin:0 0 .8em">{segments_to_html(s)}</p>'
        for s in style_entries(papers, fmt)
    )
    return (
        f'<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>참고문헌 — {html.escape(title)}</title>'
        '<style>body{font-family:"Times New Roman","바탕",serif;font-size:12pt;line-height:1.6;max-width:46em;'
        f"margin:2em auto;padding:0 1em}}</style></head><body><h3>참고문헌</h3>\n{body}\n</body></html>\n"
    )
