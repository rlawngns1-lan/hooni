"""키 없이 열 수 있는 한국 학술 DB 웹 검색 링크 (제목·검색어로 바로 검색).

확인 (2026-11-26):
- RISS: https://www.riss.kr/search/Search.do?isDetailSearch=N&searchGubun=true&query=... (검색어 전달 확인)
- DBpia: https://www.dbpia.co.kr/search/topSearch?searchOption=all&query=... (페이지 열림 확인)
- KCI: 통합검색 https://www.kci.go.kr/kciportal/po/search/poTotalSearList.kci?poSearchBean.keyword=...
  (GET 으로 검색어가 반영됨을 확인. 앱은 링크만 만들고 KCI 화면을 읽어 오지 않는다.)
"""

from __future__ import annotations

from urllib.parse import quote

from config import settings

KCI_SEARCH = "https://www.kci.go.kr/kciportal/po/search/poTotalSearList.kci?poSearchBean.keyword="


def library_proxy_url(url: str | None, prefix: str | None = None) -> str | None:
    """학교 도서관 프록시(EZproxy) 링크: '{프록시}{원문URL}'. 프록시 설정이 없으면 None.

    학교 계정으로 로그인해 정식으로 원문에 접근하도록 돕는 링크다 (앱이 대신 내려받지 않음).
    """
    prefix = prefix if prefix is not None else settings.LIBRARY_PROXY_PREFIX
    if not prefix or not url:
        return None
    return f"{prefix}{url}"


def korean_search_links(query: str) -> dict[str, str]:
    """검색어(또는 논문 제목)로 KCI·RISS·DBpia 검색 결과 링크를 만든다."""
    q = quote(query.strip())
    return {
        "KCI": f"{KCI_SEARCH}{q}",
        "RISS": f"https://www.riss.kr/search/Search.do?isDetailSearch=N&searchGubun=true&query={q}",
        "DBpia": f"https://www.dbpia.co.kr/search/topSearch?searchOption=all&query={q}",
    }
