"""검색 기록과 저장된 검색('새 논문 확인' 알림)."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass

from sqlmodel import select

from app.context import read_owner, write_owner
from app.db import get_session
from app.models import Paper, SavedSearch, SearchHistory, utcnow
from app.services.search import paper_key, search_all
from app.sources.base import SearchFilters


class SavedSearchError(Exception):
    """사용자에게 보여줄 한국어 오류."""


def filters_from_json(text: str | None) -> SearchFilters:
    """저장된 JSON 을 SearchFilters 로 되돌린다 (모르는 항목은 무시)."""
    data = json.loads(text or "{}")
    known = {k: v for k, v in data.items() if k in SearchFilters.__dataclass_fields__}
    return SearchFilters(**known)


def describe_filters(f: SearchFilters) -> str:
    """필터를 짧은 한국어로."""
    parts = []
    if f.year_from or f.year_to:
        parts.append(f"{f.year_from or ''}~{f.year_to or ''}년")
    if f.oa_only:
        parts.append("OA만")
    if f.min_citations:
        parts.append(f"피인용 {f.min_citations}+")
    if f.languages:
        parts.append("/".join({"ko": "한국어", "en": "영어"}.get(x, x) for x in f.languages))
    return ", ".join(parts) or "필터 없음"


# ---------------------------------------------------------------- 검색 기록


def list_history(limit: int = 30, db_url: str | None = None, owner: str | None = None) -> list[SearchHistory]:
    """최근 검색 기록 (같은 주제·영어 검색어는 가장 최근 것 하나만). 로그인 전이면 빈 목록."""
    owner = read_owner(owner)
    if not owner:
        return []
    with get_session(db_url) as s:
        rows = s.exec(
            select(SearchHistory).where(SearchHistory.owner == owner)
            .order_by(SearchHistory.created_at.desc(), SearchHistory.id.desc()).limit(limit * 5)
        ).all()
    seen, out = set(), []
    for r in rows:
        k = (r.query, r.expanded_keywords)
        if k not in seen:
            seen.add(k)
            out.append(r)
        if len(out) >= limit:
            break
    return out


def history_english(r: SearchHistory) -> str | None:
    """기록에 저장된 영어 검색어."""
    kws = json.loads(r.expanded_keywords or "[]")
    return kws[0] if kws else None


def clear_history(db_url: str | None = None, owner: str | None = None) -> int:
    """검색 기록을 모두 지운다 (저장된 검색은 남는다). 지운 개수를 돌려준다."""
    owner = write_owner(owner)
    with get_session(db_url) as s:
        rows = s.exec(select(SearchHistory).where(SearchHistory.owner == owner)).all()
        for r in rows:
            s.delete(r)
        s.commit()
        return len(rows)


# ---------------------------------------------------------------- 저장된 검색


def _same_english(english_query: str | None):
    """영어 검색어 비교 조건 (None 은 SQL 에서 IS NULL 로 비교해야 한다)."""
    col = SavedSearch.english_query
    return col.is_(None) if english_query is None else col == english_query


def save_search(
    query: str, english_query: str | None, filters: SearchFilters, papers: list[Paper],
    db_url: str | None = None, owner: str | None = None,
) -> SavedSearch:
    """검색을 저장한다. 지금 보이는 논문들은 '이미 본 논문'으로 기록한다. 같은 검색이 있으면 그것을 돌려준다."""
    owner = write_owner(owner)
    query = query.strip()
    if not query:
        raise SavedSearchError("저장할 검색어가 없습니다.")
    with get_session(db_url) as s:
        existing = s.exec(
            select(SavedSearch).where(SavedSearch.owner == owner, SavedSearch.query == query,
                                      _same_english(english_query))
        ).first()
        if existing:
            return existing
        row = SavedSearch(
            owner=owner,
            query=query,
            english_query=english_query,
            filters_json=json.dumps(asdict(filters), ensure_ascii=False),
            seen_keys_json=json.dumps(sorted({paper_key(p) for p in papers}), ensure_ascii=False),
        )
        s.add(row)
        s.commit()
        s.refresh(row)
        return row


def list_saved(db_url: str | None = None, owner: str | None = None) -> list[SavedSearch]:
    """저장된 검색 목록 (만든 순서). 로그인 전이면 빈 목록."""
    owner = read_owner(owner)
    if not owner:
        return []
    with get_session(db_url) as s:
        return list(s.exec(select(SavedSearch).where(SavedSearch.owner == owner).order_by(SavedSearch.id)).all())


def is_saved(query: str, english_query: str | None, db_url: str | None = None, owner: str | None = None) -> bool:
    """같은 검색이 이미 저장돼 있는지."""
    owner = read_owner(owner)
    if not owner:
        return False
    with get_session(db_url) as s:
        return s.exec(
            select(SavedSearch).where(SavedSearch.owner == owner, SavedSearch.query == query.strip(),
                                      _same_english(english_query))
        ).first() is not None


def delete_saved(saved_id: int, db_url: str | None = None, owner: str | None = None) -> None:
    """저장된 검색을 지운다."""
    owner = write_owner(owner)
    with get_session(db_url) as s:
        row = s.get(SavedSearch, saved_id)
        if row and row.owner == owner:
            s.delete(row)
            s.commit()


@dataclass
class CheckResult:
    """새 논문 확인 결과."""

    new: list[Paper]
    failed: list[str]  # 실패한 소스 안내 (있으면 결과가 불완전할 수 있음)


async def check_new(
    saved_id: int, *, sources=None, db_url: str | None = None, owner: str | None = None
) -> CheckResult:
    """저장된 검색을 다시 실행해 처음 보는 논문만 돌려주고, 그 논문들을 '본 논문'에 추가한다.

    캐시를 쓰지 않고 새로 검색한다. 일부 소스가 실패하면 성공한 소스의 결과로 비교하고 실패 안내를 함께 돌려준다.
    """
    owner = write_owner(owner)
    with get_session(db_url) as s:
        row = s.get(SavedSearch, saved_id)
    if row is None or row.owner != owner:
        raise SavedSearchError("저장된 검색을 찾을 수 없습니다 — 화면을 새로고침하세요.")
    outcome = await search_all(
        row.query, filters_from_json(row.filters_json), english_query=row.english_query,
        sources=sources, use_cache=False, db_url=db_url,
    )
    if outcome.statuses and all(st.state != "ok" for st in outcome.statuses):
        msgs = " / ".join(st.message for st in outcome.statuses if st.message)
        raise SavedSearchError(f"모든 소스 검색에 실패했습니다 — 잠시 후 다시 시도하세요. ({msgs})")
    seen = set(json.loads(row.seen_keys_json or "[]"))
    new = [p for p in outcome.papers if paper_key(p) not in seen]
    with get_session(db_url) as s:
        row = s.get(SavedSearch, saved_id)
        row.seen_keys_json = json.dumps(sorted(seen | {paper_key(p) for p in outcome.papers}), ensure_ascii=False)
        row.last_checked_at = utcnow()
        s.add(row)
        s.commit()
    failed = [f"{st.label}: {st.message}" for st in outcome.statuses if st.state == "error"]
    return CheckResult(sorted(new, key=lambda p: (p.year or 0, p.relevance), reverse=True), failed)
