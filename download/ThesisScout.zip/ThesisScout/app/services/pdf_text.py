"""PDF 본문 텍스트 추출 (PyMuPDF). 내 서재의 '본문 미리보기'에 쓴다."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pymupdf


class PdfTextError(Exception):
    """사용자에게 보여줄 한국어 오류."""


@dataclass
class PdfText:
    """추출 결과."""

    text: str
    pages: int

    @property
    def is_scanned(self) -> bool:
        """글자가 거의 없으면 스캔(이미지) PDF 로 본다."""
        return len(self.text.strip()) < 200 * max(1, min(self.pages, 3))


def extract_text(path: str | Path, max_pages: int | None = None) -> PdfText:
    """PDF 에서 본문 텍스트를 뽑는다. max_pages 를 주면 앞쪽 그만큼만."""
    path = Path(path)
    if not path.exists():
        raise PdfTextError(f"PDF 파일을 찾을 수 없습니다: {path.name} — 옮기거나 지웠다면 다시 내려받으세요.")
    try:
        with pymupdf.open(path) as doc:
            n = doc.page_count if max_pages is None else min(max_pages, doc.page_count)
            text = "\n".join(doc[i].get_text() for i in range(n))
            return PdfText(text=text, pages=doc.page_count)
    except (pymupdf.FileDataError, RuntimeError) as e:
        raise PdfTextError(f"PDF 를 열 수 없습니다({path.name}) — 파일이 손상됐거나 암호가 걸려 있을 수 있습니다.") from e
