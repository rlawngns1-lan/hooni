"""지금 사용 중인 사람(소유자)을 알려 주는 작은 연결 고리.

- 내 컴퓨터 모드(기본): 모든 데이터의 소유자는 "local" 한 명.
- 공개 모드: 로그인한 사람마다 소유자가 다르다 (app/auth.py 가 owner_provider 를 등록).
서비스 코드는 Streamlit 을 몰라도 되도록 여기서만 소유자를 묻는다.
"""

from __future__ import annotations

from collections.abc import Callable

LOCAL_OWNER = "local"

_provider: Callable[[], str | None] | None = None


class LoginRequired(Exception):
    """로그인이 필요한 작업을 로그인 없이 하려 할 때 (한국어 안내 포함)."""

    def __init__(self, msg: str = "로그인이 필요합니다 — 왼쪽 메뉴의 'Google 로 로그인' 을 눌러 주세요.") -> None:
        super().__init__(msg)


def set_owner_provider(fn: Callable[[], str | None] | None) -> None:
    """소유자를 알려 줄 함수를 등록한다 (None 이면 내 컴퓨터 모드로 되돌림)."""
    global _provider
    _provider = fn


def current_owner() -> str | None:
    """지금 사용자. 공개 모드에서 로그인하지 않았으면 None.

    안전장치: 공개 모드인데 로그인 연결(provider)이 없으면 'local' 이 아니라 None 을 돌려준다
    (모든 방문자가 한 사람으로 취급되어 서로의 서재를 보는 일이 없도록 — 기본값이 '막힘').
    """
    if _provider:
        return _provider()
    from config import settings

    return None if settings.PUBLIC_MODE else LOCAL_OWNER


def read_owner(owner: str | None = None) -> str | None:
    """읽기용 소유자 (없으면 None → 빈 결과를 돌려주면 된다)."""
    return owner or current_owner()


def write_owner(owner: str | None = None) -> str:
    """쓰기용 소유자 (로그인 안 했으면 LoginRequired)."""
    o = owner or current_owner()
    if not o:
        raise LoginRequired()
    return o
