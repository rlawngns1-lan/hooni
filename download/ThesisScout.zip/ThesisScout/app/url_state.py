"""검색 상태를 페이지 주소(URL)에 담고 되살린다.

브라우저 '뒤로 가기'·새로고침으로 페이지가 다시 열리면 Streamlit 세션이 새로 시작돼
검색 결과가 사라진다. 주소에 검색어·필터를 넣어 두면, 다시 열렸을 때 같은 검색을
(24시간 캐시로 바로) 복원할 수 있다.
예: http://localhost:8501/?q=한미동맹&en=US-ROK+alliance&yf=2000&yt=2026&sort=citations
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from app.models import DOC_TYPE_LABELS

SORTS = ("relevance", "citations", "recent")
VIEWS = ("list", "card")
LANGS = ("ko", "en")
YEAR_MIN = 1950


@dataclass
class SearchState:
    """주소에 담는 검색 상태."""

    query: str = ""
    english: str | None = None
    year_from: int = 2000
    year_to: int | None = None  # None 이면 올해
    oa_only: bool = False
    languages: list[str] = field(default_factory=list)
    min_citations: int = 0
    doc_types: list[str] = field(default_factory=list)
    sort: str = "relevance"
    view: str = "list"


def _int(value: str | None, default: int | None, lo: int, hi: int) -> int | None:
    """숫자 파라미터를 안전하게 읽는다 (이상한 값이면 기본값, 범위 밖이면 범위 안으로)."""
    try:
        return max(lo, min(hi, int(str(value))))
    except (TypeError, ValueError):
        return default


def _list(value: str | None, allowed) -> list[str]:
    return [v for v in (value or "").split(",") if v in allowed]


def encode(s: SearchState, this_year: int) -> dict[str, str]:
    """검색 상태 → 주소 파라미터 (기본값인 항목은 넣지 않아 주소를 짧게)."""
    out: dict[str, str] = {"q": s.query}
    if s.english:
        out["en"] = s.english
    if s.year_from != 2000:
        out["yf"] = str(s.year_from)
    if s.year_to and s.year_to != this_year:
        out["yt"] = str(s.year_to)
    if s.oa_only:
        out["oa"] = "1"
    if s.languages:
        out["lang"] = ",".join(s.languages)
    if s.min_citations:
        out["minc"] = str(s.min_citations)
    if s.doc_types:
        out["types"] = ",".join(s.doc_types)
    if s.sort != "relevance":
        out["sort"] = s.sort
    if s.view != "list":
        out["view"] = s.view
    return out


def decode(params: Mapping[str, str], this_year: int) -> SearchState | None:
    """주소 파라미터 → 검색 상태. 검색어(q)가 없으면 None."""
    query = (params.get("q") or "").strip()
    if not query:
        return None
    year_from = _int(params.get("yf"), 2000, YEAR_MIN, this_year)
    year_to = _int(params.get("yt"), this_year, YEAR_MIN, this_year)
    if year_from > year_to:
        year_from, year_to = year_to, year_from
    sort = params.get("sort") or "relevance"
    view = params.get("view") or "list"
    return SearchState(
        query=query[:300],
        english=((params.get("en") or "").strip()[:300] or None),
        year_from=year_from,
        year_to=year_to,
        oa_only=params.get("oa") == "1",
        languages=_list(params.get("lang"), LANGS),
        min_citations=_int(params.get("minc"), 0, 0, 100000) or 0,
        doc_types=_list(params.get("types"), DOC_TYPE_LABELS),
        sort=sort if sort in SORTS else "relevance",
        view=view if view in VIEWS else "list",
    )
