"""설정 페이지 — 소스별 활성 상태와 키 설정 방법 안내."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st  # noqa: E402

from app.auth import is_logged_in, is_public  # noqa: E402
from app.services import library  # noqa: E402
from app.theme import apply_theme, page_header  # noqa: E402

from app.sources import get_sources  # noqa: E402
from config import settings  # noqa: E402

st.set_page_config(page_title="설정 — Thesis Scout", page_icon=":material/settings:", layout="wide")
apply_theme()
page_header("설정", "검색 소스 상태와 개인정보 안내입니다." if is_public()
            else "검색 소스 상태와 API 키·도서관 프록시 설정 방법을 안내합니다.")

st.subheader("검색 소스 상태")
for src in get_sources():
    if src.is_enabled():
        extra = " (키 등록됨)" if src.api_key else (" (키 없이 사용 중)" if src.key_env else "")
        st.success(f"**{src.label}** — 사용 가능{extra}")
    elif src.name in ("kci", "riss"):
        st.info(f"**{src.label}** — **링크 방식**: 검색어·논문 제목으로 {src.label} 사이트 검색을 바로 엽니다."
                + ("" if is_public() else f" 키(`{src.key_env}`)를 넣으면 앱 안에 결과가 함께 나옵니다 (선택)."))
    else:
        st.warning(f"**{src.label}** — {src.disabled_reason()}")
st.caption("국내 학술지 논문은 Crossref(키 불필요)로도 함께 찾습니다. DOI 를 등록한 KCI 등재지 논문이 많이 포함됩니다.")

if is_public():
    # ---------------------------------------------------------------- 공개판: 개인정보 안내·내 데이터 지우기
    st.subheader("개인정보 안내")
    st.markdown(
        """
- **로그인:** Google 계정으로 로그인합니다. 이 사이트는 **비밀번호를 받거나 저장하지 않습니다.**
- **저장하는 것:** 사용자를 구분하는 Google 고유번호 1개와, 내가 직접 저장한 **서재(논문·태그·메모·프로젝트)·검색 기록·저장된 검색**뿐입니다.
  이름과 이메일은 왼쪽 메뉴 아래의 계정 표시에만 쓰고 데이터베이스에 저장하지 않습니다.
- **볼 수 있는 사람:** 다른 이용자는 내 서재와 검색 기록을 볼 수 없습니다. 다만 사이트 운영자는 데이터베이스 관리 목적으로
  기술적으로 접근할 수 있으니, 메모에 민감한 개인정보는 적지 마세요.
- **맡겨 처리하는 곳:** 사이트 서버(Streamlit Community Cloud), 데이터베이스(Neon), 로그인(Google).
- **쿠키:** 로그인 상태를 기억하는 쿠키를 씁니다 (30일 유지, '로그아웃'으로 삭제).
- **검색어:** 논문을 찾기 위해 검색어가 Semantic Scholar·OpenAlex·Crossref 같은 공개 학술 DB 로 전달됩니다.
- **지우기:** 아래 버튼으로 내 데이터를 언제든 모두 지울 수 있습니다.
"""
    )
    st.subheader("이용 안내")
    st.markdown(
        """
- 논문 정보·초록의 출처는 Semantic Scholar, OpenAlex, Crossref 등 공개 학술 데이터베이스이며,
  **초록의 저작권은 원저작자·출판사에 있습니다.**
- PDF 는 합법적으로 공개된(Open Access) 것의 링크만 제공하며, 이 사이트는 PDF 를 보관하지 않습니다.
- AI 요약 기능은 없습니다. 논문에 인용할 때는 반드시 원문을 확인하세요.
"""
    )
    if is_logged_in():
        with st.popover("내 데이터 모두 지우기", icon=":material/delete_forever:"):
            st.write("내 서재·프로젝트·검색 기록·저장된 검색을 **모두 지웁니다. 되돌릴 수 없습니다.**")
            if st.button("네, 모두 지웁니다", type="primary"):
                counts = library.delete_all_user_data()
                st.session_state.pop("outcome", None)
                st.success(f"지웠습니다: 서재 {counts['LibraryItem']}편, 프로젝트 {counts['Project']}개, "
                           f"검색 기록 {counts['SearchHistory']}개, 저장된 검색 {counts['SavedSearch']}개.")
    st.caption("AI 요약 기능은 없습니다. 기계 요약(TLDR)이 보이면 참고용이며, 인용할 때는 반드시 원문을 확인하세요.")
    st.stop()

st.subheader("무료 PDF 찾기 (Unpaywall · CORE)")
from app.sources.core import CoreClient  # noqa: E402
from app.sources.unpaywall import UnpaywallClient  # noqa: E402

for c in (UnpaywallClient(), CoreClient()):
    if c.is_enabled():
        st.success(f"**{c.label}** — 사용 가능")
    else:
        st.info(f"**{c.label}** — {c.disabled_reason()}")
st.caption("둘 다 꺼져 있어도 Semantic Scholar·OpenAlex 가 알려주는 무료 PDF 는 그대로 내려받을 수 있습니다.")

st.subheader("서지정보 보완 (Crossref — 인용 내보내기용)")
if settings.CROSSREF_MAILTO:
    st.success("**Crossref** — 사용 가능 (이메일 등록됨: 더 넉넉한 요청 한도)")
else:
    st.success("**Crossref** — 사용 가능 (키 불필요). `.env` 에 CROSSREF_MAILTO 로 본인 이메일을 넣으면 요청 한도가 넉넉해집니다 (선택).")

st.subheader("API 키 등록 방법")
st.markdown(
    f"""
1. 프로젝트 폴더의 `.env` 파일을 메모장으로 엽니다. (없으면 `.env.example` 을 복사해 이름을 `.env` 로 바꾸세요.)
2. `KCI_API_KEY=발급받은키` 처럼 `=` 뒤에 값을 붙여 넣고 저장합니다.
3. 앱을 껐다가(PowerShell 에서 `Ctrl + C`) 다시 실행합니다.

발급처는 `README.md` 의 "API 키 발급 안내" 표를 참고하세요.

- 학교 도서관 프록시: {"✅ 등록됨" if settings.LIBRARY_PROXY_PREFIX else "❌ 없음 (선택)"}
"""
)
with st.expander(":material/account_balance: 학교 도서관 프록시 주소 넣는 법"):
    st.markdown(
        """
학교 도서관 홈페이지의 **교외 접속(EZproxy)** 안내에서 "주소 앞에 붙이는 형식"을 찾으세요.
보통 `https://(도서관 프록시 주소)/login?url=` 처럼 **`?url=` 로 끝나는** 형태입니다.

`.env` 에 `LIBRARY_PROXY_PREFIX=https://ezproxy.학교.ac.kr/login?url=` 처럼 넣으면,
구독이 필요한 논문에 **도서관** 링크가 생겨 학교 계정으로 원문을 볼 수 있습니다.
"""
    )

st.subheader("핵심 저널 목록")
st.markdown(f"⭐ 배지가 붙는 저널 목록은 `{settings.CORE_JOURNALS_PATH.relative_to(settings.BASE_DIR)}` 에서 수정할 수 있습니다.")
