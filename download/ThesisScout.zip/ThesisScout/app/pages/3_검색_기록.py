"""검색 기록 페이지 — 저장된 검색의 새 논문 확인('알림'), 최근 검색 다시 하기."""

from __future__ import annotations

import asyncio
import sys
from datetime import timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st  # noqa: E402

from app.auth import require_login  # noqa: E402
from app.theme import apply_theme, page_header  # noqa: E402

from app.services import library, saved_searches  # noqa: E402
from app.services.oa_finder import oa_lookup_available  # noqa: E402
from app.services.saved_searches import SavedSearchError  # noqa: E402
from app.ui_common import flash, render_papers, show_flashes  # noqa: E402

st.set_page_config(page_title="검색 기록 — Thesis Scout", page_icon=":material/history:", layout="wide")
apply_theme()
page_header("검색 기록", "저장한 검색의 새 논문을 확인하고, 지난 검색을 다시 엽니다.")
show_flashes()
require_login("검색 기록")


def local_time(dt) -> str:
    """DB 의 UTC 시각을 내 컴퓨터 시간으로."""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone().strftime("%Y-%m-%d %H:%M")


def rerun_search(query: str, english: str | None) -> None:
    """검색 화면으로 가서 같은 검색을 다시 실행한다."""
    st.session_state["rerun_search"] = {"query": query, "english": english}
    st.switch_page("main.py")


def check(saved_id: int) -> None:
    """저장된 검색 하나의 새 논문을 확인해 화면 상태에 담는다."""
    try:
        st.session_state[f"new_{saved_id}"] = asyncio.run(saved_searches.check_new(saved_id))
    except SavedSearchError as e:
        flash("error", str(e))


# ---------------------------------------------------------------- 저장된 검색
st.subheader("저장된 검색")
saved_list = saved_searches.list_saved()
if not saved_list:
    st.info("저장된 검색이 없습니다. 검색 화면의 결과 위에 있는 **🔔 이 검색 저장**을 누르면, "
            "나중에 여기서 그 뒤로 새로 나온 논문만 골라 볼 수 있습니다.")
else:
    st.caption("앱이 내 컴퓨터에서만 돌아가므로 알림이 저절로 오지는 않습니다. 가끔 이 화면에서 **새 논문 확인**을 눌러 주세요.")
    if len(saved_list) > 1 and st.button(f"모두 확인 ({len(saved_list)}개 — 개당 5~15초)", type="primary", icon=":material/notifications:"):
        with st.spinner("저장된 검색을 차례로 다시 검색하는 중…"):
            for row in saved_list:
                check(row.id)
        st.rerun()

    saved, local, oa_lookup = library.saved_keys(), library.local_pdf_paths(), oa_lookup_available()
    for row in saved_list:
        f = saved_searches.filters_from_json(row.filters_json)
        with st.container(border=True):
            c1, c2, c3, c4 = st.columns([4, 1.3, 1.1, 0.9])
            title = f"**{row.query}**" + (f" · 영어: `{row.english_query}`" if row.english_query else "")
            c1.markdown(title)
            c1.caption(f"{saved_searches.describe_filters(f)} · 마지막 확인 {local_time(row.last_checked_at)}")
            if c2.button("새 논문 확인", icon=":material/notifications:", key=f"chk_{row.id}", use_container_width=True):
                with st.spinner("다시 검색해 처음 보는 논문을 찾는 중…"):
                    check(row.id)
                st.rerun()
            if c3.button("다시 검색", icon=":material/replay:", key=f"re_{row.id}", use_container_width=True,
                         help="검색 화면에서 전체 결과를 봅니다 (필터는 검색 화면의 현재 설정을 따릅니다)."):
                rerun_search(row.query, row.english_query)
            with c4.popover("", icon=":material/delete:", use_container_width=True):
                st.write("이 저장된 검색을 지울까요?")
                if st.button("네, 삭제", key=f"del_{row.id}"):
                    saved_searches.delete_saved(row.id)
                    st.session_state.pop(f"new_{row.id}", None)
                    flash("success", f"'{row.query}' 저장된 검색을 지웠습니다.")
                    st.rerun()

            result = st.session_state.get(f"new_{row.id}")
            if result is not None:
                new = result.new
                if result.failed:
                    st.warning("일부 소스가 실패해 결과가 불완전할 수 있습니다 — 잠시 후 다시 확인하세요. "
                               + " / ".join(result.failed))
                if not new:
                    st.success("새로 나온 논문이 없습니다.")
                else:
                    st.markdown(f"**🆕 새 논문 {len(new)}편** (지난번 확인 이후 처음 보이는 논문, 최신순)")
                    with st.expander("새 논문 보기", expanded=len(new) <= 5):
                        render_papers(new, saved, local, oa_lookup, key_prefix=f"s{row.id}")

# ---------------------------------------------------------------- 최근 검색 기록
st.subheader("최근 검색 기록")
history = saved_searches.list_history()
if not history:
    st.info("아직 검색 기록이 없습니다.")
else:
    for i, h in enumerate(history):
        english = saved_searches.history_english(h)
        c1, c2 = st.columns([5, 1])
        c1.markdown(f"{h.query}" + (f" · 영어: `{english}`" if english else ""))
        c1.caption(local_time(h.created_at))
        if c2.button("다시 검색", icon=":material/replay:", key=f"hist_{i}", use_container_width=True):
            rerun_search(h.query, english)
    with st.popover("검색 기록 모두 지우기", icon=":material/delete_sweep:"):
        st.write("최근 검색 기록을 모두 지울까요? (저장된 검색은 그대로 남습니다)")
        if st.button("네, 지우기"):
            n = saved_searches.clear_history()
            flash("success", f"검색 기록 {n}개를 지웠습니다.")
            st.rerun()
