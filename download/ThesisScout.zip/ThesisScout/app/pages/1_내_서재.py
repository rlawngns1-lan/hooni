"""내 서재 페이지 — 저장한 논문의 태그·메모·읽음 상태·프로젝트 관리."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st  # noqa: E402

from app.auth import is_public, require_login  # noqa: E402
from app.theme import apply_theme, md_text, page_header, safe_url  # noqa: E402

from app.models import DOC_TYPE_LABELS, READ_STATUS_LABELS  # noqa: E402
from app.services import citation_export as ce  # noqa: E402
from app.services import library  # noqa: E402
from app.services.metadata import enrich_records, needs_enrichment  # noqa: E402
from app.services.library import LibraryError  # noqa: E402
from app.services.links import library_proxy_url  # noqa: E402
from app.services.pdf_text import PdfTextError, extract_text  # noqa: E402
from app.ui_common import cb_download, cb_open_pdf, flash, open_network, show_flashes  # noqa: E402

st.set_page_config(page_title="내 서재 — Thesis Scout", page_icon=":material/bookmarks:", layout="wide")
apply_theme()
page_header("내 서재", "저장한 논문을 프로젝트·태그·메모로 정리하고, 참고문헌으로 내보냅니다.")
show_flashes()
require_login("내 서재")
PUBLIC = is_public()  # 공개판: PDF 를 서버에 저장·열기 하지 않음

projects = library.list_projects()
proj_names = {p.id: p.name for p in projects}

# ---------------------------------------------------------------- 사이드바: 거르기
with st.sidebar:
    st.header("보기")
    proj_filter = st.selectbox(
        "프로젝트", [None, *proj_names], format_func=lambda i: "전체" if i is None else proj_names[i]
    )
    status_filter = st.selectbox(
        "읽음 상태", [None, *READ_STATUS_LABELS], format_func=lambda s: "전체" if s is None else READ_STATUS_LABELS[s]
    )
    tags = library.all_tags()
    tag_filter = st.selectbox("태그", [None, *tags], format_func=lambda t: "전체" if t is None else f"#{t}")
    text_filter = st.text_input("제목·저자·메모에서 찾기")

# ---------------------------------------------------------------- 프로젝트 관리
with st.expander(":material/folder: 프로젝트 관리 (예: 1장 이론적 배경, 3장 사례분석)"):
    with st.form("new_project", clear_on_submit=True):
        c1, c2 = st.columns([1, 2])
        name = c1.text_input("새 프로젝트 이름")
        desc = c2.text_input("설명 (선택)")
        if st.form_submit_button("만들기"):
            try:
                library.create_project(name, desc)
                flash("success", f"'{name.strip()}' 프로젝트를 만들었습니다.")
                st.rerun()
            except LibraryError as e:
                st.error(str(e))
    for p in projects:
        c1, c2 = st.columns([4, 1])
        c1.markdown(f"**{p.name}** {('— ' + p.description) if p.description else ''}")
        with c2.popover("삭제", icon=":material/delete:"):
            st.write(f"'{p.name}' 프로젝트를 지울까요? 안의 논문은 서재에 그대로 남습니다.")
            if st.button("네, 삭제", key=f"delproj_{p.id}"):
                library.delete_project(p.id)
                flash("success", f"'{p.name}' 프로젝트를 지웠습니다.")
                st.rerun()

# ---------------------------------------------------------------- 목록
rows = library.list_items(
    project_id=proj_filter, read_status=status_filter, tag=tag_filter, text=text_filter or None
)
counts = {s: 0 for s in READ_STATUS_LABELS}
for item, _ in library.list_items():
    counts[item.read_status] = counts.get(item.read_status, 0) + 1
st.caption(" · ".join(f"{READ_STATUS_LABELS[s]} {n}편" for s, n in counts.items()))

# ---------------------------------------------------------------- 인용 내보내기
if rows:
    with st.expander(":material/ios_share: 인용 내보내기 (BibTeX · RIS · APA · 한국정치학회)",
                     expanded=st.session_state.pop("_export_open", False)):
        by_id = {item.id: (item, rec) for item, rec in rows}
        chosen = st.multiselect(
            "내보낼 논문 (지금 화면에 보이는 논문이 기본으로 모두 선택됩니다)",
            list(by_id), default=list(by_id),
            format_func=lambda i: f"{by_id[i][1].title[:70]} ({by_id[i][1].year or '연도 미상'})",
        )
        fmt = st.radio(
            "형식", list(ce.FORMATS), format_func=lambda f: ce.FORMATS[f]["label"], horizontal=True
        )
        recs = [by_id[i][1] for i in chosen]

        # Crossref 로 권·호·쪽 채우기
        todo = [r for r in recs if needs_enrichment(r)]
        if todo:
            st.caption(f"DOI 가 있는 {len(todo)}편은 Crossref(무료 공식 서지 DB)에서 권·호·쪽·출판사를 채울 수 있습니다.")
            if st.button(f"Crossref 로 서지정보 채우기 ({len(todo)}편)", icon=":material/sync:"):
                with st.spinner("Crossref 에서 서지정보를 가져오는 중…"):
                    res = asyncio.run(enrich_records([r.id for r in todo]))
                flash("success", f"{res.checked}편 확인, {res.updated}편의 정보를 채웠습니다.")
                for n in res.notes:
                    flash("warning", n)
                st.session_state["_export_open"] = True
                st.rerun()

        papers = [library.record_to_paper(r) for r in recs]
        lacking = [(p, ce.missing_info(p)) for p in papers]
        lacking = [(p, m) for p, m in lacking if m]
        if lacking:
            with st.expander(f"⚠️ 정보가 빠진 논문 {len(lacking)}편 — 원문에서 확인해 직접 보충하세요"):
                for p, m in lacking:
                    st.markdown(f"- {p.title[:70]} — 빠진 정보: {', '.join(m)}")

        if papers:
            stem = f"참고문헌_{fmt}"
            ext = ce.FORMATS[fmt]["ext"]
            with_abstract = fmt == "ris" and st.checkbox(
                "초록 포함 (Zotero 에서 초록도 보기)", value=False,
                help="초록의 저작권은 출판사·저자에게 있습니다. 개인 연구용으로만 쓰고 파일을 남에게 공유하지 마세요.",
            )
            text = ce.export_text(papers, fmt, include_abstract=with_abstract)
            c1, c2 = st.columns(2)
            c1.download_button(
                f"⬇️ 파일로 받기 (.{ext})", text.encode("utf-8-sig" if ext == "txt" else "utf-8"),
                file_name=f"{stem}.{ext}", mime=ce.FORMATS[fmt]["mime"], use_container_width=True,
            )
            if fmt in ce.STYLE_FORMATS:
                c2.download_button(
                    "⬇️ 워드용 (.html, 기울임꼴 유지)", ce.export_html(papers, fmt).encode("utf-8"),
                    file_name=f"{stem}.html", mime="text/html", use_container_width=True,
                )
                st.markdown("**미리보기**")
                for seg in ce.style_entries(papers, fmt):
                    st.markdown(ce.segments_to_markdown(seg))
            else:
                st.code(text, language="latex" if fmt == "bibtex" else None)
            if fmt == "kpsa":
                st.caption(
                    "ℹ️ 한국정치학회 양식은 정치학계의 저자-연도 표기(예: 이종은. 2000. “민주시민의 덕성”. "
                    "『한국정치학회보』 34집 1호. 121-122.)를 따랐습니다. 투고 전에 학회·학교의 최신 원고작성요강과 대조하세요."
                )
            elif fmt == "apa":
                st.caption("ℹ️ APA 7판은 제목을 문장형 대소문자(첫 글자·고유명사만 대문자)로 쓰므로, 원제목 그대로 나온 제목은 직접 고쳐 주세요.")
            else:
                st.caption("ℹ️ .bib / .ris 파일은 Zotero·EndNote·Mendeley 의 '가져오기(Import)' 메뉴로 불러올 수 있습니다.")

if not rows:
    st.info("서재가 비어 있거나 조건에 맞는 논문이 없습니다. 검색 화면에서 논문 옆 **저장** 버튼을 눌러 담아 보세요.")

for item, rec in rows:
    paper = library.record_to_paper(rec)
    with st.container(border=True):
        star = "⭐ " if rec.is_core_journal else ""
        st.markdown(f"#### {star}{md_text(rec.title)}")
        if rec.title_alt:
            st.caption(md_text(rec.title_alt))
        authors = ", ".join(paper.authors[:3]) + (" 외" if len(paper.authors) > 3 else "")
        meta = [authors, str(rec.year or "연도 미상"), rec.venue or "", DOC_TYPE_LABELS.get(rec.doc_type, "기타")]
        st.caption(md_text(" · ".join(m for m in meta if m)))

        # 원문 접근
        b = st.columns(5)
        if PUBLIC:
            if safe_url(rec.oa_pdf_url):  # 공개판: 서버에 저장하지 않고 공개 PDF 를 바로 연다
                b[0].link_button("무료 PDF", safe_url(rec.oa_pdf_url), icon=":material/description:", use_container_width=True)
        elif rec.local_pdf_path and Path(rec.local_pdf_path).exists():
            b[0].button("PDF 열기", icon=":material/description:", key=f"open_{item.id}", on_click=cb_open_pdf,
                        args=(rec.local_pdf_path,), use_container_width=True)
        elif rec.oa_pdf_url:
            b[0].button("PDF 저장", icon=":material/download:", key=f"dl_{item.id}", on_click=cb_download,
                        args=(paper, rec.oa_pdf_url), use_container_width=True)
        if rec.doi:
            b[1].link_button("DOI", f"https://doi.org/{rec.doi}", icon=":material/link:", use_container_width=True)
        if safe_url(rec.landing_url):
            b[2].link_button("논문 페이지", safe_url(rec.landing_url), icon=":material/open_in_new:", use_container_width=True)
        proxy = library_proxy_url(rec.landing_url or (f"https://doi.org/{rec.doi}" if rec.doi else None))
        if proxy and not rec.oa_pdf_url:
            b[3].link_button("도서관", proxy, icon=":material/account_balance:", use_container_width=True)
        if rec.doi and b[4].button("인용", icon=":material/hub:", key=f"net_{item.id}", use_container_width=True):
            open_network(paper)

        # 정리 정보 편집
        with st.form(f"edit_{item.id}"):
            c1, c2 = st.columns(2)
            status = c1.selectbox(
                "읽음 상태", list(READ_STATUS_LABELS), index=list(READ_STATUS_LABELS).index(item.read_status),
                format_func=lambda s: READ_STATUS_LABELS[s], key=f"st_{item.id}",
            )
            proj_opts = [None, *proj_names]
            proj = c2.selectbox(
                "프로젝트", proj_opts,
                index=proj_opts.index(item.project_id) if item.project_id in proj_opts else 0,
                format_func=lambda i: "프로젝트 없음" if i is None else proj_names[i], key=f"pj_{item.id}",
            )
            tag_text = st.text_input(
                "태그 (쉼표로 구분)", ", ".join(library.get_tags(item)), key=f"tg_{item.id}",
                placeholder="예: 동맹이론, 확장억제, 과정추적",
            )
            note = st.text_area("메모", item.note, key=f"nt_{item.id}", placeholder="이 논문을 어디에 쓸지, 인상 깊은 주장 등")
            if st.form_submit_button("변경 저장", icon=":material/save:"):
                library.update_item(
                    item.id, tags=library.parse_tags(tag_text), note=note, read_status=status, project_id=proj
                )
                flash("success", f"저장했습니다: {rec.title[:50]}")
                st.rerun()

        c1, c2 = st.columns([4, 1])
        if rec.local_pdf_path and not PUBLIC:
            with c1.expander(":material/article: 본문 텍스트 미리보기 (PDF 에서 추출)"):
                try:
                    extracted = extract_text(rec.local_pdf_path, max_pages=2)
                    if extracted.is_scanned:
                        st.warning("글자를 거의 찾지 못했습니다 — 스캔(이미지) PDF 일 수 있어 본문 글자를 뽑기 어렵습니다.")
                    st.caption(f"전체 {extracted.pages}쪽 중 앞 2쪽")
                    st.text(extracted.text[:1500])
                except PdfTextError as e:
                    st.error(str(e))
        elif rec.abstract:
            with c1.expander("초록 보기"):
                st.write(rec.abstract)
        with c2.popover("서재에서 빼기", icon=":material/bookmark_remove:"):
            st.write("서재에서 뺄까요? (내려받은 PDF 파일은 지우지 않습니다)")
            if st.button("네, 빼기", key=f"rm_{item.id}"):
                library.remove_from_library(item.id)
                flash("success", f"서재에서 뺐습니다: {rec.title[:50]}")
                st.rerun()
