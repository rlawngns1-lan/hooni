"""인용 네트워크 페이지 — 한 논문의 후속 연구(인용한 논문)와 선행 연구(참고문헌)를 탐색한다."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd  # noqa: E402
import streamlit as st  # noqa: E402

from app.theme import apply_theme, md_text, page_header  # noqa: E402

from app.models import Paper  # noqa: E402
from app.sources.base import clean_doi  # noqa: E402
from app.services import library  # noqa: E402
from app.services.citation_network import (  # noqa: E402
    DIRECTIONS,
    clear_cache,
    fetch_network,
    sort_network,
    year_counts,
)
from app.services.oa_finder import oa_lookup_available  # noqa: E402
from app.ui_common import network_params, render_papers, show_flashes, view_mode_picker  # noqa: E402

SORTS = {"citations": "피인용 많은 순", "influential": "영향력 있는 인용 먼저", "recent": "최신순"}
PAGE_SIZE = 20

st.set_page_config(page_title="인용 네트워크 — Thesis Scout", page_icon=":material/hub:", layout="wide")
apply_theme()
page_header("인용 네트워크", "이 논문을 인용한 후속 연구와, 이 논문이 인용한 선행 연구를 따라갑니다.")
show_flashes()

# ---------------------------------------------------------------- 대상 논문 고르기
# 뒤로 가기·새로고침으로 세션이 새로 시작됐으면 주소(?doi=…&title=…)에서 대상 논문을 되살린다
if "network_paper" not in st.session_state and (doi_param := clean_doi(st.query_params.get("doi"))):
    year_param = st.query_params.get("year", "")
    st.session_state["network_paper"] = Paper(
        doi=doi_param, title=(st.query_params.get("title") or doi_param)[:300],
        year=int(year_param) if year_param.isdigit() else None,
    ).model_dump()
data = st.session_state.get("network_paper")
lib_papers = [library.record_to_paper(rec) for _, rec in library.list_items() if rec.doi]
if data is None and not lib_papers:
    st.info(
        "검색 결과나 내 서재의 논문 카드에서 **🕸 인용 네트워크** 버튼을 누르면 여기에서 그 논문의 "
        "후속 연구와 선행 연구를 볼 수 있습니다. (DOI 가 있는 논문만 가능)"
    )
    st.stop()

with st.sidebar:
    st.header("대상 논문")
    if lib_papers:
        options = {p.doi: p for p in lib_papers}
        current = Paper.model_validate(data) if data else None
        if current and current.doi not in options:
            options = {current.doi: current, **options}
        picked = st.selectbox(
            "내 서재에서 고르기", list(options),
            index=list(options).index(current.doi) if current else 0,
            format_func=lambda d: f"{options[d].title[:50]} ({options[d].year or '연도 미상'})",
        )
        if not current or picked != current.doi:
            st.session_state["network_paper"] = options[picked].model_dump()
            st.rerun()
    st.header("보기")
    sort = st.radio("정렬", list(SORTS), format_func=lambda s: SORTS[s])
    core_only = st.checkbox("⭐ 핵심 저널만")
    oa_only = st.checkbox("🟢 Open Access 만")
    text = st.text_input("제목에서 찾기")
    view_mode_picker(st)

target = Paper.model_validate(st.session_state["network_paper"])
if st.query_params.to_dict() != (wanted := network_params(target)):
    st.query_params.from_dict(wanted)
with st.container(border=True):
    st.markdown(f"### {'⭐ ' if target.is_core_journal else ''}{md_text(target.title)}")
    authors = ", ".join(target.authors[:3]) + (" 외" if len(target.authors) > 3 else "")
    st.caption(md_text(" · ".join(x for x in [authors, str(target.year or "연도 미상"), target.venue or "",
                                               f"피인용 {target.citation_count:,}" if target.citation_count else ""]
                                  if x)))
    if target.doi:
        st.link_button("DOI", f"https://doi.org/{target.doi}", icon=":material/link:")

saved, local, oa_lookup = library.saved_keys(), library.local_pdf_paths(), oa_lookup_available()
tabs = st.tabs([f":material/south: {DIRECTIONS['citations']}", f":material/north: {DIRECTIONS['references']}"])
for tab, direction in zip(tabs, DIRECTIONS):
    with tab:
        state_key = f"net_{direction}_{target.doi}"
        if state_key not in st.session_state:
            with st.spinner("Semantic Scholar·OpenAlex 에서 인용 관계를 불러오는 중… (5~15초)"):
                st.session_state[state_key] = asyncio.run(fetch_network(target, direction))
        res = st.session_state[state_key]
        for note in res.notes:
            st.warning(note)
        if not res.papers:
            if not res.notes:
                st.info("관련 논문을 찾지 못했습니다.")
            continue

        total = f"전체 약 {res.total:,}편 중 " if res.total else ""
        st.caption(
            f"{total}{len(res.papers)}편을 불러왔습니다 (피인용 많은 논문 위주)"
            + (" · 24시간 캐시" if res.cached else "")
            + ". '영향력 있는 인용'은 Semantic Scholar 가 본문에서 비중 있게 다룬 인용으로 판단한 것입니다."
        )
        if direction == "citations":
            counts = year_counts(res.papers)
            if len(counts) > 1:
                st.markdown("**연도별 후속 연구 수** (불러온 논문 기준 — 이 주제가 언제 활발히 다뤄졌는지 참고)")
                st.bar_chart(pd.DataFrame({"편수": counts}), height=180, color="#1E3A5F")

        papers = res.papers
        if core_only:
            papers = [p for p in papers if p.is_core_journal]
        if oa_only:
            papers = [p for p in papers if p.is_oa]
        if text:
            papers = [p for p in papers if text.lower() in p.title.lower()]
        papers = sort_network(papers, sort)
        if not papers:
            st.info("조건에 맞는 논문이 없습니다. 왼쪽 조건을 바꿔 보세요.")
            continue

        shown = st.session_state.get(f"{state_key}_n", PAGE_SIZE)
        render_papers(papers[:shown], saved, local, oa_lookup, key_prefix=direction[:3])
        if len(papers) > shown:
            if st.button(f"더 보기 ({len(papers) - shown}편 남음)", key=f"more_{direction}"):
                st.session_state[f"{state_key}_n"] = shown + PAGE_SIZE
                st.rerun()

if st.button("새로 불러오기", icon=":material/refresh:", help="24시간 캐시를 무시하고 다시 가져옵니다."):
    for direction in DIRECTIONS:
        st.session_state.pop(f"net_{direction}_{target.doi}", None)
    clear_cache(target.doi)
    st.rerun()
