"""화면 꾸미기: 공통 CSS, 페이지 머리말, 상태 배지, 링크 태그.

색·글꼴의 기본값은 .streamlit/config.toml 에 있고, 여기서는 그 위에 세부 모양을 다듬는다.
사용자에게 보이는 글자(논문 제목 등)는 모두 html.escape 하고, 링크는 http(s) 주소만 쓴다.
"""

from __future__ import annotations

import html
from urllib.parse import urlparse

import streamlit as st

NAVY = "#1E3A5F"
GOLD = "#A8832F"
MUTED = "#6B6F76"

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@500;600;700&display=swap');

/* 본문 폭·여백 */
.block-container { max-width: 1100px; padding-top: 3.2rem; padding-bottom: 4rem; }

/* 머리말 */
.ts-kicker { font-size: .72rem; letter-spacing: .18em; text-transform: uppercase; color: #A8832F;
             font-weight: 700; margin-bottom: .15rem; }
h1.ts-title, .ts-title { font-family: 'Noto Serif KR', serif !important; font-size: 2.05rem !important;
            font-weight: 700 !important; color: #1E3A5F !important; line-height: 1.25 !important; margin: 0 !important;
            padding: 0 !important; }
.ts-sub { color: #6B6F76; font-size: .95rem; margin-top: .35rem; }
.ts-rule { height: 1px; background: linear-gradient(90deg, #1E3A5F 0, #1E3A5F 56px, #E3DFD6 56px);
           margin: 1rem 0 1.4rem; border: 0; }

/* 테두리 있는 상자(결과 행·카드)를 흰 종이처럼 */
[data-testid="stVerticalBlockBorderWrapper"]:has(> div > [data-testid="stVerticalBlock"]) {
  background: #FFFFFF; box-shadow: 0 1px 2px rgba(31, 35, 40, .04);
}

/* 결과 한 줄 */
.ts-row-title { font-size: 1.02rem; font-weight: 600; line-height: 1.45; margin: 0 0 .2rem; }
.ts-row-title a { color: #1F2328 !important; text-decoration: none; }
.ts-row-title a:hover { color: #1E4E8C !important; text-decoration: underline; text-underline-offset: 3px; }
.ts-star { color: #A8832F; margin-right: .25rem; }
.ts-alt-title { color: #4A4F57; font-size: .84rem; line-height: 1.4; margin: -.05rem 0 .2rem; }
.ts-meta { color: #6B6F76; font-size: .84rem; line-height: 1.5; }
.ts-meta .ts-venue { font-style: italic; color: #4A4F57; }
.ts-meta .ts-dot { margin: 0 .4rem; color: #C9C4B8; }
.ts-tags { margin-top: .5rem; display: flex; flex-wrap: wrap; gap: .35rem; }
.ts-tag { display: inline-block; font-size: .76rem; padding: .12rem .55rem; border-radius: 999px;
          border: 1px solid #E3DFD6; background: #FBFAF7; color: #1E3A5F !important; text-decoration: none !important;
          line-height: 1.5; }
.ts-tag:hover { border-color: #1E3A5F; background: #EEF2F7; }
.ts-tag.pdf { border-color: #2E7D5B; color: #2E7D5B !important; background: #F1F8F4; }
.ts-badge { display: inline-block; font-size: .7rem; padding: .05rem .45rem; border-radius: 4px; margin-left: .35rem;
            vertical-align: 1px; font-weight: 600; letter-spacing: .02em; }
.ts-badge.oa { background: #E8F3EC; color: #2E7D5B; }
.ts-badge.core { background: #F7F0DF; color: #8A6A20; }
.ts-badge.infl { background: #EEF2F7; color: #1E3A5F; }

/* 소스 상태 배지 */
.ts-status { display: flex; flex-wrap: wrap; gap: .45rem; margin: .2rem 0 .6rem; }
.ts-pill { display: inline-flex; align-items: center; gap: .4rem; font-size: .8rem; padding: .25rem .7rem;
           border-radius: 999px; border: 1px solid #E3DFD6; background: #FFFFFF; color: #1F2328; }
.ts-pill b { font-weight: 600; }
.ts-pill .d { width: .5rem; height: .5rem; border-radius: 50%; display: inline-block; }
.ts-pill.ok .d { background: #2E7D5B; } .ts-pill.off .d { background: #B9B3A6; } .ts-pill.err .d { background: #B3412F; }
.ts-pill a { color: #1E4E8C !important; text-decoration: none; }
.ts-pill.err { border-color: #EBC9C1; }

/* 결과 개수 머리 */
.ts-count { font-family: 'Noto Serif KR', serif; font-size: 1.25rem; font-weight: 600; color: #1F2328; }
.ts-count span { font-family: Pretendard, sans-serif; color: #6B6F76; font-size: .85rem; font-weight: 400; margin-left: .5rem; }

/* 사이드바 */
section[data-testid="stSidebar"] h2 { font-size: .78rem !important; letter-spacing: .14em; text-transform: uppercase;
  color: #6B6F76 !important; font-family: Pretendard, sans-serif !important; font-weight: 700 !important; }

/* 버튼은 조금 더 단정하게 */
.stButton > button, .stDownloadButton > button, .stLinkButton > a { font-weight: 500; }
.stButton > button[kind="primary"], .stFormSubmitButton > button[kind="primaryFormSubmit"] { letter-spacing: .02em; }

/* 확장 영역 제목 */
[data-testid="stExpander"] summary p { font-weight: 500; }
</style>
"""


def apply_theme() -> None:
    """공통 CSS 를 넣고, 공개 모드면 사이드바에 계정(로그인) 상자를 그린다. 각 페이지 맨 위에서 한 번 호출."""
    from app.auth import account_box

    st.markdown(CSS, unsafe_allow_html=True)
    account_box()


def esc(text: object) -> str:
    """HTML 에 넣을 글자를 안전하게 바꾼다."""
    return html.escape(str(text), quote=True)


def md_text(text: object) -> str:
    """st.markdown·caption 에 외부 글자(논문 제목·TLDR·주소의 값)를 넣을 때 마크다운 기호를 무력화한다.

    예: 제목에 '[클릭](http://...)' 이 들어 있어도 링크가 아니라 글자 그대로 보이게.
    """
    import re

    return re.sub(r"([\\`*_{}\[\]()#+\-.!|<>$~])", r"\\\1", str(text))


def safe_url(url: str | None) -> str | None:
    """http(s) 주소만 허용 (javascript: 같은 주소는 버린다)."""
    if not url:
        return None
    try:
        scheme = urlparse(url).scheme.lower()
    except ValueError:
        return None
    return url if scheme in ("http", "https") else None


def page_header(title: str, subtitle: str = "", kicker: str = "Thesis Scout") -> None:
    """페이지 머리말: 작은 영문 머리 + 명조체 제목 + 설명 + 얇은 선."""
    st.markdown(
        f'<div class="ts-kicker">{esc(kicker)}</div><h1 class="ts-title">{esc(title)}</h1>'
        + (f'<div class="ts-sub">{esc(subtitle)}</div>' if subtitle else "")
        + '<hr class="ts-rule">',
        unsafe_allow_html=True,
    )


def tag_links(links: list[tuple[str, str]]) -> str:
    """(이름, 주소) 목록 → 작은 태그 모양 링크들 (HTML). 새 탭에서 열린다."""
    parts = []
    for name, url in links:
        u = safe_url(url)
        if not u:
            continue
        cls = "ts-tag pdf" if "PDF" in name else "ts-tag"
        parts.append(f'<a class="{cls}" href="{esc(u)}" target="_blank" rel="noopener noreferrer">{esc(name)}</a>')
    return f'<div class="ts-tags">{"".join(parts)}</div>' if parts else ""


def status_pills(items: list[tuple[str, str, str, str | None]]) -> None:
    """소스별 상태 배지. items: (상태 ok/off/err, 이름, 설명, 링크 또는 None)."""
    parts = []
    for state, label, text, url in items:
        u = safe_url(url)
        body = f'<a href="{esc(u)}" target="_blank" rel="noopener noreferrer">{esc(text)} →</a>' if u else esc(text)
        parts.append(f'<span class="ts-pill {esc(state)}"><span class="d"></span><b>{esc(label)}</b>{body}</span>')
    st.markdown(f'<div class="ts-status">{"".join(parts)}</div>', unsafe_allow_html=True)


def count_header(n: int, note: str = "") -> None:
    """'검색 결과 N건' 머리."""
    st.markdown(f'<div class="ts-count">검색 결과 {n:,}건<span>{esc(note)}</span></div>', unsafe_allow_html=True)
