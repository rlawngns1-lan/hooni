"""Thesis Scout 검색 화면 (Streamlit 진입점). 실행: streamlit run app/main.py"""

from __future__ import annotations

import asyncio
import sys
from datetime import date
from pathlib import Path

# `streamlit run app/main.py` 로 실행해도 app/, config/ 를 불러올 수 있게 프로젝트 폴더를 경로에 추가
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st  # noqa: E402

from app.models import DOC_TYPE_LABELS  # noqa: E402
from app.services import library, saved_searches  # noqa: E402
from app.services.links import korean_search_links  # noqa: E402
from app.services.oa_finder import oa_lookup_available  # noqa: E402
from app.services.search import (  # noqa: E402
    SORT_OPTIONS,
    SearchFilters,
    apply_filters,
    save_history,
    search_all,
    sort_papers,
)
from app import url_state  # noqa: E402
from app.context import LoginRequired  # noqa: E402
from app.ui_common import flash, render_papers, show_flashes, view_mode_picker  # noqa: E402
from app.url_state import SearchState  # noqa: E402
from app.theme import apply_theme, count_header, esc, page_header, status_pills, tag_links  # noqa: E402

THIS_YEAR = date.today().year

st.set_page_config(page_title="Thesis Scout — 논문 검색", page_icon=":material/search:", layout="wide")


def render_filters(d: SearchState) -> tuple[SearchFilters, str]:
    """사이드바 필터·정렬을 그리고 값을 돌려준다. d 는 처음 보여줄 값 (주소에서 복원한 값 또는 기본값)."""
    with st.sidebar:
        st.header("필터")
        years = st.slider("출판연도", url_state.YEAR_MIN, THIS_YEAR, (d.year_from, d.year_to or THIS_YEAR))
        oa_only = st.checkbox("Open Access(무료 공개 PDF)만 보기", value=d.oa_only)
        languages = st.multiselect(
            "언어", ["ko", "en"], default=d.languages, format_func=lambda x: {"ko": "한국어", "en": "영어"}[x]
        )
        min_cit = st.number_input("최소 피인용 수", min_value=0, value=d.min_citations, step=5)
        doc_types = st.multiselect(
            "문헌 유형", list(DOC_TYPE_LABELS), default=d.doc_types, format_func=lambda x: DOC_TYPE_LABELS[x]
        )
        st.divider()
        sort = st.radio("정렬", list(SORT_OPTIONS), index=list(SORT_OPTIONS).index(d.sort),
                        format_func=lambda x: SORT_OPTIONS[x])
        view_mode_picker(st)
        st.caption("필터를 **넓혔다면**(예: 연도 범위 확대) 검색 버튼을 다시 눌러야 결과가 추가됩니다.")
    f = SearchFilters(
        year_from=years[0],
        year_to=years[1],
        oa_only=oa_only,
        min_citations=int(min_cit),
        languages=languages,
        doc_types=doc_types,
    )
    return f, sort


def run_search(query: str, english: str | None, filters: SearchFilters, *, record: bool = True) -> None:
    """검색을 실행하고 결과를 세션에 담는다. record=False 면 검색 기록에 남기지 않는다(복원할 때)."""
    with st.spinner("여러 학술 DB 를 동시에 검색하는 중… (보통 5~15초)"):
        outcome = asyncio.run(search_all(query, filters, english_query=english))
    if record:
        save_history(query, english, filters)
    st.session_state.update(outcome=outcome, query=query, english=english, filters=filters)


def last_search() -> SearchState | None:
    """가장 최근 검색(검색 기록)을 되살릴 상태로 바꾼다."""
    rows = saved_searches.list_history(limit=1)
    if not rows:
        return None
    h = rows[0]
    f = saved_searches.filters_from_json(h.filters)
    return SearchState(
        query=h.query, english=saved_searches.history_english(h),
        year_from=f.year_from or 2000, year_to=f.year_to, oa_only=f.oa_only, languages=list(f.languages),
        min_citations=f.min_citations, doc_types=list(f.doc_types),
    )


def restore_from_url() -> SearchState | None:
    """새 세션(뒤로 가기·새로고침·앱 다시 열기)이면 되살릴 검색을 돌려준다.

    1순위: 주소(?q=…)에 담긴 검색, 2순위: 가장 최근 검색 기록.
    """
    if "filter_defaults" in st.session_state:
        return None  # 이미 이 세션에서 시작함
    state = url_state.decode(st.query_params.to_dict(), THIS_YEAR) or last_search()
    st.session_state["filter_defaults"] = state or SearchState()
    if state:
        st.session_state.update(query=state.query, english=state.english, view_mode=state.view)
    return state


def main() -> None:
    """검색 페이지."""
    apply_theme()
    page_header("논문 검색", "국제정치·외교안보 연구를 위한 학술 DB 통합 검색 — "
                "Semantic Scholar · OpenAlex · Crossref · KCI · RISS")

    restored = restore_from_url()
    filters, sort = render_filters(st.session_state["filter_defaults"])
    show_flashes()

    # '검색 기록' 화면에서 [다시 검색]을 누르고 넘어온 경우
    rerun = st.session_state.pop("rerun_search", None)

    with st.form("search"):
        query = st.text_input(
            "연구 주제", value=rerun["query"] if rerun else st.session_state.get("query", ""),
            placeholder="예: 한미동맹과 확장억제 / middle power diplomacy South Korea",
        )
        english = st.text_input(
            "영어 검색어 (선택)",
            value=(rerun["english"] or "") if rerun else (st.session_state.get("english") or ""),
            placeholder="예: US-ROK alliance extended deterrence",
            help="한국어 주제를 입력했다면 해외 DB(Semantic Scholar, OpenAlex)용 영어 검색어를 적어 주세요. "
            "비워 두면 주제를 그대로 보냅니다. 국내 DB(Crossref 국내 학술지, KCI, RISS)에는 연구 주제가 그대로 갑니다.",
        )
        submitted = st.form_submit_button("검색", type="primary", icon=":material/search:")

    if rerun:
        run_search(rerun["query"], rerun["english"], filters)
    elif submitted:
        if not query.strip():
            st.warning("연구 주제를 입력하세요.")
            return
        run_search(query.strip(), english.strip() or None, filters)
    elif restored and "outcome" not in st.session_state:
        st.caption("이전 검색을 되살리는 중입니다 (24시간 안의 검색은 저장된 결과를 바로 씁니다).")
        run_search(restored.query, restored.english, filters, record=False)

    outcome = st.session_state.get("outcome")
    if outcome is None:
        if st.query_params:
            st.query_params.clear()
        st.info("주제를 입력하고 검색을 눌러 보세요.")
        return

    # 지금 검색어·필터를 주소에 담아 둔다 → 뒤로 가기·새로고침해도 같은 검색이 되살아난다
    current = SearchState(
        query=st.session_state["query"], english=st.session_state.get("english"),
        year_from=filters.year_from or url_state.YEAR_MIN, year_to=filters.year_to, oa_only=filters.oa_only,
        languages=list(filters.languages), min_citations=filters.min_citations, doc_types=list(filters.doc_types),
        sort=sort, view=st.session_state.get("view_mode", "list"),
    )
    wanted = url_state.encode(current, THIS_YEAR)
    if st.query_params.to_dict() != wanted:  # 바뀔 때만 고쳐 써서 브라우저 기록이 불필요하게 늘지 않게
        st.query_params.from_dict(wanted)
    st.session_state["filter_defaults"] = current  # 다른 화면에 다녀와도 필터가 그대로 보이게

    # 소스별 상태 — 키가 없는 KCI·RISS 는 같은 검색어로 사이트에서 바로 검색하는 링크로 대신한다
    links = korean_search_links(st.session_state["query"])
    pills = []
    for s in outcome.statuses:
        name = s.label.split(" (")[0]
        if s.state == "ok":
            pills.append(("ok", name, f"{s.count}건" + (" · 저장된 결과" if s.cached else ""), None))
        elif s.state == "disabled" and s.label in links:
            pills.append(("off", name, "사이트에서 검색", links[s.label]))
        elif s.state == "disabled":
            pills.append(("off", name, "꺼짐", None))
        else:
            pills.append(("err", name, "실패", None))
    status_pills(pills)
    for s in outcome.statuses:
        if s.state == "error" and s.message:
            st.caption(f"{s.label} — {s.message}")

    st.markdown(
        f'<div class="ts-meta" style="margin-top:.2rem">국내 DB 에서 \'{esc(st.session_state["query"])}\' 바로 검색'
        f'</div>{tag_links(list(links.items()))}',
        unsafe_allow_html=True,
    )

    papers = sort_papers(apply_filters(outcome.papers, filters), sort)
    st.write("")
    c1, c2 = st.columns([3, 1], vertical_alignment="bottom")
    with c1:
        count_header(len(papers), f"‘{st.session_state['query']}’ · {SORT_OPTIONS[sort]}")
    q, en = st.session_state["query"], st.session_state.get("english")
    if saved_searches.is_saved(q, en):
        c2.button("저장된 검색", icon=":material/notifications_active:", disabled=True, use_container_width=True,
                  help="'검색 기록' 화면에서 새 논문을 확인할 수 있습니다.")
    elif c2.button("이 검색 저장", icon=":material/notifications:", use_container_width=True,
                   help="저장해 두면 '검색 기록' 화면에서 이후 새로 나온 논문만 골라 볼 수 있습니다."):
        try:
            saved_searches.save_search(q, en, st.session_state.get("filters", filters), outcome.papers)
            flash("success", f"'{q}' 검색을 저장했습니다. '검색 기록' 화면에서 새 논문을 확인하세요.")
        except LoginRequired as e:
            flash("info", str(e))
        st.rerun()
    unknown = sum(p.citation_count is None for p in papers)
    if filters.min_citations and unknown:
        st.caption(f"최소 피인용 {filters.min_citations} 필터를 켰지만, 피인용 수를 알 수 없는 논문 {unknown}편"
                   "(주로 Crossref 로 찾은 국내 학술지 논문)은 빼지 않고 보여 줍니다.")
    if not papers:
        st.warning("조건에 맞는 논문이 없습니다. 필터를 넓히거나 다른 검색어로 시도해 보세요.")
    saved, local, oa_lookup = library.saved_keys(), library.local_pdf_paths(), oa_lookup_available()
    render_papers(papers, saved, local, oa_lookup)
    st.caption("논문 정보 출처: Semantic Scholar · OpenAlex · Crossref (초록의 저작권은 원저작자·출판사에 있습니다). "
               "PDF 는 합법적으로 공개된(Open Access) 것의 링크만 제공합니다. 인용할 때는 반드시 원문을 확인하세요.")


main()
