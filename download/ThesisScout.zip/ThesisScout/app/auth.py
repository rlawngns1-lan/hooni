"""로그인 (공개 모드 전용) — Streamlit 기본 로그인(st.login, OpenID Connect)으로 Google 계정 사용.

확인한 공식 문서 (2026-11-26, Streamlit 1.67):
- https://docs.streamlit.io/develop/concepts/connections/authentication
- https://docs.streamlit.io/develop/api-reference/user/st.login , st.user , st.logout
요점: Authlib>=1.3.2 필요. secrets.toml 의 [auth] 에 redirect_uri·cookie_secret, [auth.google] 에
client_id·client_secret·server_metadata_url. st.login("google") / st.user.is_logged_in / st.logout().
로그인 쿠키는 30일 유지. 앱은 비밀번호를 받거나 저장하지 않는다.

저장하는 개인정보는 최소한으로: 사용자 구분용 Google 고유번호(sub)만 DB 에 남긴다 ('google:<sub>').
이름·이메일은 화면 표시용으로 로그인 쿠키에서 읽을 뿐 DB 에 저장하지 않는다.
"""

from __future__ import annotations

import streamlit as st

from app.context import set_owner_provider
from config import settings

PROVIDER = "google"


def is_public() -> bool:
    """공개(인터넷) 모드인지."""
    return settings.PUBLIC_MODE


def auth_configured() -> bool:
    """로그인 설정(secrets 의 [auth])이 있는지."""
    try:
        return "auth" in st.secrets
    except Exception:  # secrets.toml 이 아예 없을 때
        return False


def _logged_in_user():
    try:
        user = st.user
        return user if user.is_logged_in else None
    except Exception:
        return None


def _owner_from_login() -> str | None:
    """로그인한 사람의 고유 ID ('google:<sub>'). 로그인 전이면 None."""
    user = _logged_in_user()
    if user is None:
        return None
    sub = user.get("sub")  # 이메일로 대신하지 않는다 — DB 에는 고유번호만 저장한다는 안내와 맞추기 위해
    return f"{PROVIDER}:{sub}" if sub else None


def is_logged_in() -> bool:
    """내 컴퓨터 모드는 항상 True, 공개 모드는 로그인했을 때만 True."""
    return (not is_public()) or _owner_from_login() is not None


# 공개 모드면 서비스들이 '지금 사용자'를 로그인 정보에서 얻도록 연결 (모듈을 불러올 때 한 번)
set_owner_provider(_owner_from_login if is_public() else None)


def _login() -> None:
    st.login(PROVIDER)


def account_box() -> None:
    """사이드바 맨 아래의 계정 상자 (공개 모드에서만)."""
    if not is_public():
        return
    with st.sidebar:
        st.divider()
        if not auth_configured():
            st.warning("관리자 설정 필요: 로그인 설정([auth])이 없어 저장 기능을 쓸 수 없습니다.")
            return
        user = _logged_in_user()
        if user is None:
            st.caption("로그인하면 내 서재·검색 기록이 저장됩니다.")
            st.button("Google 로 로그인", icon=":material/login:", on_click=_login, use_container_width=True)
        else:
            st.caption(f"{user.get('name') or ''}  \n{user.get('email') or ''}")
            st.button("로그아웃", icon=":material/logout:", on_click=st.logout, use_container_width=True)


def require_login(feature: str) -> None:
    """공개 모드에서 로그인하지 않았으면 안내와 로그인 버튼을 보여 주고 화면을 멈춘다."""
    if is_logged_in():
        return
    st.info(f"**{feature}** 은(는) 로그인한 뒤 쓸 수 있습니다. Google 계정으로 로그인하면 "
            "내 서재·검색 기록이 나만 볼 수 있게 저장됩니다.")
    if auth_configured():
        st.button("Google 로 로그인", icon=":material/login:", on_click=_login, type="primary")
    st.stop()
