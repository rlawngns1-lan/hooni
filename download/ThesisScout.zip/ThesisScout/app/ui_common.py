"""여러 페이지가 함께 쓰는 화면 동작 (저장·다운로드·PDF 열기)."""

from __future__ import annotations

import asyncio
import hashlib
import os
import re
from pathlib import Path

import streamlit as st

from app.auth import is_public
from app.context import LoginRequired
from app.models import DOC_TYPE_LABELS, Paper
from app.services import library
from app.services.downloader import DownloadError, download_pdf, make_filename
from app.services.search import paper_key
from app.theme import esc, md_text, safe_url, tag_links


def widget_key(p: Paper, prefix: str) -> str:
    """논문마다 겹치지 않는 위젯 키."""
    return f"{prefix}_{hashlib.md5(paper_key(p).encode('utf-8')).hexdigest()[:12]}"


def flash(kind: str, msg: str) -> None:
    """다음 화면 갱신 때 보여줄 알림을 남긴다."""
    st.session_state.setdefault("_flash", []).append((kind, msg))


def show_flashes() -> None:
    """남겨 둔 알림을 보여주고 비운다."""
    for kind, msg in st.session_state.pop("_flash", []):
        {"success": st.success, "error": st.error, "warning": st.warning, "info": st.info}.get(kind, st.info)(msg)


def cb_save(p: Paper) -> None:
    """[서재에 저장] 버튼 동작. 공개 모드에서 로그인 전이면 로그인 안내."""
    try:
        library.save_to_library(p)
    except LoginRequired as e:
        flash("info", str(e))
        return
    flash("success", f"서재에 저장했습니다: {p.title[:60]}")


def cb_download(p: Paper, url: str) -> None:
    """[PDF 저장] 버튼 동작: OA PDF 를 받아 data/papers 에 저장하고 서재에도 담는다 (내 컴퓨터 모드 전용)."""
    if is_public():
        flash("info", "인터넷 공개판에서는 PDF 를 서버에 저장하지 않습니다 — '무료 PDF' 링크로 바로 여세요.")
        return
    try:
        path = asyncio.run(download_pdf(url, make_filename(p)))
    except DownloadError as e:
        flash("error", str(e))
        return
    p = p.model_copy(update={"oa_pdf_url": p.oa_pdf_url or url})
    item = library.save_to_library(p)
    library.set_local_pdf(item.paper_id, str(path))
    flash("success", f"PDF 를 저장하고 서재에 담았습니다: data/papers/{path.name}")


def cb_find_and_download(p: Paper) -> None:
    """[무료 PDF 찾기] 버튼 동작: Unpaywall·CORE 로 OA PDF 를 찾아 있으면 바로 저장한다 (내 컴퓨터 모드 전용)."""
    from app.services.oa_finder import find_oa_pdf

    if is_public():
        return
    result = asyncio.run(find_oa_pdf(p))
    if result.url:
        flash("info", f"{result.found_by} 에서 무료 PDF 를 찾았습니다.")
        cb_download(p, result.url)
    else:
        flash("info", "합법적으로 공개된 PDF 를 찾지 못했습니다. " + " ".join(result.notes)
              + " DOI·도서관 링크로 원문을 확인하세요.")


NETWORK_PAGE = "pages/2_인용_네트워크.py"


def network_params(p: Paper) -> dict[str, str]:
    """인용 네트워크 화면 주소에 담을 값 (새로고침·뒤로 가기 때 대상 논문을 되살리는 데 씀)."""
    out = {"doi": p.doi or "", "title": p.title[:200]}
    if p.year:
        out["year"] = str(p.year)
    return out


def open_network(p: Paper) -> None:
    """인용 네트워크 화면으로 이동한다 (버튼 본문에서 호출). 주소에 논문 정보를 함께 넘긴다."""
    st.session_state["network_paper"] = p.model_dump()
    st.switch_page(NETWORK_PAGE, query_params=network_params(p))


VIEW_MODES = {"list": "간단 목록 (제목 + 링크)", "card": "자세히 (초록·버튼)"}


def view_mode_picker(container=st.sidebar) -> str:
    """결과 보기 방식 선택 (여러 화면이 같은 설정을 공유)."""
    current = st.session_state.get("view_mode", "list")
    mode = container.radio("결과 보기", list(VIEW_MODES), index=list(VIEW_MODES).index(current),
                           format_func=lambda v: VIEW_MODES[v])
    st.session_state["view_mode"] = mode  # 위젯 키가 아닌 일반 값으로 저장해 화면을 옮겨도 유지
    return mode


def paper_links(p: Paper) -> list[tuple[str, str]]:
    """논문 하나에 붙일 링크 (이름, 주소): 무료 PDF, DOI, 논문 페이지, 도서관, KCI·RISS·DBpia 제목 검색."""
    from app.services.links import korean_search_links, library_proxy_url

    out: list[tuple[str, str]] = []
    if p.oa_pdf_url:
        out.append(("무료 PDF", p.oa_pdf_url))
    if p.doi:
        out.append(("DOI", f"https://doi.org/{p.doi}"))
    if p.landing_url and not (p.doi and p.doi in p.landing_url):
        out.append(("논문 페이지", p.landing_url))
    proxy = library_proxy_url(p.landing_url or (f"https://doi.org/{p.doi}" if p.doi else None))
    if proxy and not p.is_oa:
        out.append(("도서관", proxy))
    out += list(korean_search_links(p.title).items())
    return out


def paper_head_html(p: Paper, *, with_type: bool = False) -> str:
    """제목(링크)·배지·서지 한 줄을 HTML 로 (목록·카드 공용)."""
    from app.sources import get_sources

    labels = {s.name: s.label.split(" (")[0] for s in get_sources()}
    main_url = safe_url(f"https://doi.org/{p.doi}" if p.doi else (p.landing_url or p.oa_pdf_url))
    star = '<span class="ts-star" title="핵심 저널">★</span>' if p.is_core_journal else ""
    title = (f'<a href="{esc(main_url)}" target="_blank" rel="noopener noreferrer">{esc(p.title)}</a>'
             if main_url else esc(p.title))
    badges = ""
    if p.is_oa:
        badges += '<span class="ts-badge oa">OPEN ACCESS</span>'
    if p.is_core_journal:
        badges += '<span class="ts-badge core">핵심 저널</span>'
    if p.is_influential:
        badges += '<span class="ts-badge infl">영향력 있는 인용</span>'
    authors = ", ".join(p.authors[:3]) + (" 외" if len(p.authors) > 3 else "")
    meta = [esc(authors or "저자 정보 없음"), esc(p.year or "연도 미상")]
    if p.venue:
        meta.append(f'<span class="ts-venue">{esc(p.venue)}</span>')
    if p.citation_count:
        meta.append(f"피인용 {p.citation_count:,}")
    elif p.citation_count is None:
        meta.append("피인용 정보 없음")
    if with_type:
        meta.append(esc(DOC_TYPE_LABELS.get(p.doc_type, "기타")))
    if p.sources:
        meta.append(esc(" · ".join(labels.get(s, s) for s in p.sources)))
    dot = '<span class="ts-dot">|</span>'
    alt = f'<div class="ts-alt-title">{esc(p.title_alt)}</div>' if p.title_alt else ""
    return (f'<div class="ts-row-title">{star}{title}{badges}</div>{alt}'
            f'<div class="ts-meta">{dot.join(meta)}</div>')


def render_paper_row(p: Paper, saved: set[str], *, key_prefix: str = "", show_network: bool = True) -> None:
    """간단 목록 한 줄: 제목(링크) + 서지 한 줄 + 링크 태그 + 저장·인용 버튼."""
    with st.container(border=True):
        c1, c2 = st.columns([7, 1.25], vertical_alignment="center")
        c1.markdown(paper_head_html(p) + tag_links(paper_links(p)), unsafe_allow_html=True)
        if paper_key(p) in saved:
            c2.button("서재에 있음", key=widget_key(p, key_prefix + "rsaved"), icon=":material/bookmark_added:",
                      disabled=True, use_container_width=True)
        else:
            c2.button("저장", key=widget_key(p, key_prefix + "rsave"), icon=":material/bookmark_add:",
                      on_click=cb_save, args=(p,), use_container_width=True)
        if show_network and p.doi and c2.button(
            "인용", key=widget_key(p, key_prefix + "rnet"), icon=":material/hub:",
            use_container_width=True, help="인용 네트워크 보기 (후속 연구·선행 연구)",
        ):
            open_network(p)


def render_papers(
    papers: list[Paper], saved: set[str], local: dict[str, str], oa_lookup: bool, *, key_prefix: str = ""
) -> None:
    """현재 보기 방식(간단 목록/자세히)으로 논문 목록을 그린다."""
    mode = st.session_state.get("view_mode", "list")
    for p in papers:
        if mode == "card":
            render_paper_card(p, saved, local, oa_lookup, key_prefix=key_prefix)
        else:
            render_paper_row(p, saved, key_prefix=key_prefix)


def render_paper_card(
    p: Paper,
    saved: set[str],
    local: dict[str, str],
    oa_lookup: bool,
    *,
    key_prefix: str = "",
    show_network: bool = True,
) -> None:
    """논문 카드 한 장 (자세히 보기): 머리 + 링크 태그 + 버튼 + TLDR·초록."""
    key = paper_key(p)
    wk = lambda name: widget_key(p, key_prefix + name)  # noqa: E731
    with st.container(border=True):
        st.markdown(paper_head_html(p, with_type=True) + tag_links(paper_links(p)), unsafe_allow_html=True)

        acts = st.columns(4)
        if key in saved:
            acts[0].button("서재에 있음", key=wk("saved"), icon=":material/bookmark_added:", disabled=True,
                           use_container_width=True)
        else:
            acts[0].button("서재에 저장", key=wk("save"), icon=":material/bookmark_add:", on_click=cb_save,
                           args=(p,), use_container_width=True)
        if is_public():
            pass  # 공개판은 PDF 를 서버에 저장하지 않는다 — 위의 '무료 PDF' 태그로 바로 연다
        elif key in local and Path(local[key]).exists():
            acts[1].button("PDF 열기", key=wk("open"), icon=":material/description:", on_click=cb_open_pdf,
                           args=(local[key],), use_container_width=True)
        elif p.oa_pdf_url:
            acts[1].button("PDF 저장", key=wk("dl"), icon=":material/download:", on_click=cb_download,
                           args=(p, p.oa_pdf_url), use_container_width=True,
                           help="data/papers 폴더에 저장하고 서재에도 담습니다.")
        elif p.doi and oa_lookup:
            acts[1].button("무료 PDF 찾기", key=wk("find"), icon=":material/travel_explore:",
                           on_click=cb_find_and_download, args=(p,), use_container_width=True,
                           help="Unpaywall·CORE 에서 합법적으로 공개된 PDF 를 찾아봅니다.")
        if show_network and p.doi:
            if acts[2].button("인용 네트워크", key=wk("net"), icon=":material/hub:", use_container_width=True,
                              help="이 논문을 인용한 후속 연구와, 이 논문이 인용한 선행 연구를 봅니다."):
                open_network(p)

        if p.tldr:
            st.markdown(f"**TLDR** (Semantic Scholar 기계 요약, 영어): {md_text(p.tldr)}")
            st.caption("자동 요약은 참고용입니다. 인용할 때는 반드시 원문을 확인하세요.")
        if p.abstract:
            with st.expander("초록 보기"):
                st.write(p.abstract)
        else:
            st.caption("초록 정보가 없습니다.")


def cb_open_pdf(path: str) -> None:
    """[PDF 열기] 버튼 동작: 컴퓨터의 기본 PDF 프로그램으로 연다."""
    if not Path(path).exists():
        flash("error", "PDF 파일을 찾을 수 없습니다 — 옮기거나 지웠다면 다시 내려받으세요.")
        return
    try:
        os.startfile(path)  # type: ignore[attr-defined]  # 윈도우 전용
    except (AttributeError, OSError):
        flash("info", f"PDF 위치: {path}")
