@echo off
rem ============================================================
rem  Thesis Scout 실행 파일 - 더블클릭하면 됩니다.
rem  처음 한 번은 필요한 프로그램을 설치하느라 1~3분 걸립니다.
rem ============================================================
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Thesis Scout

rem ---- 1. 파이썬 찾기 ----
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto :no_python
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul
if errorlevel 1 goto :old_python

rem ---- 2. 이 프로그램 전용 파이썬 환경 만들기 - 처음 한 번만 ----
rem  압축을 푼 위치와 상관없이 짧은 고정 경로에 둔다: 윈도우 경로 길이 제한, OneDrive 동기화 문제를 피하기 위해
rem  개발용 폴더처럼 이 폴더 안에 .venv 가 이미 있으면 그것을 쓴다
set "VENV=%LOCALAPPDATA%\ThesisScout\venv"
if exist ".venv\Scripts\python.exe" set "VENV=%~dp0.venv"
if exist "%VENV%\Scripts\python.exe" goto :check_packages
echo [1/3] 전용 파이썬 환경을 만드는 중입니다 - 처음 한 번만...
%PY% -m venv "%VENV%"
if errorlevel 1 goto :fail_venv

:check_packages
rem ---- 3. 필요한 패키지 설치 - 처음 한 번, 또는 새 버전으로 바뀌었을 때만 ----
fc /b requirements.txt "%VENV%\requirements.installed" >nul 2>nul
if not errorlevel 1 goto :env_file
echo [2/3] 필요한 프로그램을 설치하는 중입니다 - 처음 한 번만, 1~3분 걸립니다...
"%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 goto :fail_pip
copy /y requirements.txt "%VENV%\requirements.installed" >nul

:env_file
rem ---- 4. 설정 파일(.env)이 없으면 빈 설정 파일을 만든다 ----
if not exist ".env" copy ".env.example" ".env" >nul

if /i "%~1"=="--setup-only" (
  echo 설치 확인을 마쳤습니다.
  exit /b 0
)

rem ---- 5. 실행 ----
echo [3/3] Thesis Scout 를 여는 중입니다. 잠시 뒤 인터넷 브라우저가 열립니다.
echo        브라우저가 안 열리면 주소창에 http://localhost:8501 을 입력하세요.
echo        다 쓰면 이 검은 창을 닫으면 프로그램이 꺼집니다.
start "" /min powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 5; Start-Process 'http://localhost:8501'"
"%VENV%\Scripts\python.exe" -m streamlit run app\main.py --server.headless true --server.port 8501
echo.
echo 프로그램이 꺼졌습니다. 오류 내용이 위에 있다면 그대로 캡처해 전달해 주세요.
pause
exit /b 0

:no_python
echo.
echo [안내] 이 컴퓨터에 파이썬이 설치되어 있지 않습니다.
echo   1. https://www.python.org/downloads/ 에서 Download Python 버튼을 눌러 설치하세요.
echo   2. 설치 첫 화면 아래쪽의 "Add python.exe to PATH" 를 꼭 체크하세요.
echo   3. 설치가 끝나면 이 파일을 다시 더블클릭하세요.
echo.
pause
exit /b 1

:old_python
echo.
echo [안내] 파이썬 버전이 너무 낮습니다. 3.11 이상이 필요합니다.
echo   https://www.python.org/downloads/ 에서 최신 버전을 설치한 뒤 다시 실행하세요.
echo.
pause
exit /b 1

:fail_venv
echo.
echo [오류] 전용 파이썬 환경을 만들지 못했습니다.
echo   폴더를 바탕화면 같은 곳으로 옮긴 뒤 다시 실행해 보세요.
echo.
pause
exit /b 1

:fail_pip
echo.
echo [오류] 필요한 프로그램을 설치하지 못했습니다. 인터넷 연결을 확인한 뒤 다시 실행하세요.
echo   계속 안 되면 위 오류 내용을 캡처해 전달해 주세요.
echo.
pause
exit /b 1
